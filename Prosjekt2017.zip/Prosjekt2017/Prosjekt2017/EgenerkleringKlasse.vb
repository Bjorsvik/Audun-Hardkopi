﻿Public Class EgenerkleringKlasse

    'Public Function loopcb()
    '    Dim p As New Control
    '    Dim cb As String
    '    Dim rb As New RadioButton
    '    For Each c In egenerklering.Controls
    '        If TypeOf c Is Panel Then
    '            For Each b In p.Controls
    '                If TypeOf b Is RadioButton Then
    '                    If b.Equals(1) Then
    '                        cb = 1
    '                    ElseIf b.Equals(0) Then
    '                        cb = 0
    '                    End If
    '                End If
    '            Next
    '        End If
    '    Next
    '    Return (MsgBox(cb))
    'End Function

    'Public Function GetControls()
    '    Dim cb As Boolean
    '    For Each c In egenerklering.Controls
    '        If TypeOf c Is Panel Then
    '            For Each b In c
    '                If TypeOf b Is CheckBox Then
    '                    If b.Equals(1) Then
    '                        cb = 1
    '                    ElseIf b.Equals(0) Then
    '                        cb = 0
    '                    End If
    '                End If
    '            Next
    '        End If
    '    Next
    '    Return (cb)
    'End Function
End Class