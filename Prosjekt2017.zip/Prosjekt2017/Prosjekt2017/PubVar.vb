﻿Module PubVar
    'Globale variabler
    Public personnummer As String
    Public brukerType As String
    Public ansattBruker As String
    Public personID As Integer
End Module
