﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class egenerklering
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.btnSendInn = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rb612 = New System.Windows.Forms.RadioButton()
        Me.rb611 = New System.Windows.Forms.RadioButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.rb622 = New System.Windows.Forms.RadioButton()
        Me.rb621 = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.rb642 = New System.Windows.Forms.RadioButton()
        Me.rb641 = New System.Windows.Forms.RadioButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.rb652 = New System.Windows.Forms.RadioButton()
        Me.rb651 = New System.Windows.Forms.RadioButton()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.rb662 = New System.Windows.Forms.RadioButton()
        Me.rb661 = New System.Windows.Forms.RadioButton()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.rb672 = New System.Windows.Forms.RadioButton()
        Me.rb671 = New System.Windows.Forms.RadioButton()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.rb632 = New System.Windows.Forms.RadioButton()
        Me.rb631 = New System.Windows.Forms.RadioButton()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.rb132 = New System.Windows.Forms.RadioButton()
        Me.rb131 = New System.Windows.Forms.RadioButton()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.rb142 = New System.Windows.Forms.RadioButton()
        Me.rb141 = New System.Windows.Forms.RadioButton()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.rb122 = New System.Windows.Forms.RadioButton()
        Me.rb121 = New System.Windows.Forms.RadioButton()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.rb112 = New System.Windows.Forms.RadioButton()
        Me.rb111 = New System.Windows.Forms.RadioButton()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.rb232 = New System.Windows.Forms.RadioButton()
        Me.rb231 = New System.Windows.Forms.RadioButton()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.rb222 = New System.Windows.Forms.RadioButton()
        Me.rb221 = New System.Windows.Forms.RadioButton()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.rb212 = New System.Windows.Forms.RadioButton()
        Me.rb211 = New System.Windows.Forms.RadioButton()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.rb252 = New System.Windows.Forms.RadioButton()
        Me.rb251 = New System.Windows.Forms.RadioButton()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.rb242 = New System.Windows.Forms.RadioButton()
        Me.rb241 = New System.Windows.Forms.RadioButton()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.rb332 = New System.Windows.Forms.RadioButton()
        Me.rb331 = New System.Windows.Forms.RadioButton()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.rb322 = New System.Windows.Forms.RadioButton()
        Me.rb321 = New System.Windows.Forms.RadioButton()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.rb312 = New System.Windows.Forms.RadioButton()
        Me.rb311 = New System.Windows.Forms.RadioButton()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.rb362 = New System.Windows.Forms.RadioButton()
        Me.rb361 = New System.Windows.Forms.RadioButton()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.rb352 = New System.Windows.Forms.RadioButton()
        Me.rb351 = New System.Windows.Forms.RadioButton()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.rb342 = New System.Windows.Forms.RadioButton()
        Me.rb341 = New System.Windows.Forms.RadioButton()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.rb372 = New System.Windows.Forms.RadioButton()
        Me.rb371 = New System.Windows.Forms.RadioButton()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.rb382 = New System.Windows.Forms.RadioButton()
        Me.rb381 = New System.Windows.Forms.RadioButton()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.rb742 = New System.Windows.Forms.RadioButton()
        Me.rb741 = New System.Windows.Forms.RadioButton()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.rb732 = New System.Windows.Forms.RadioButton()
        Me.rb731 = New System.Windows.Forms.RadioButton()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.rb722 = New System.Windows.Forms.RadioButton()
        Me.rb721 = New System.Windows.Forms.RadioButton()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.rb712 = New System.Windows.Forms.RadioButton()
        Me.rb711 = New System.Windows.Forms.RadioButton()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.rb412 = New System.Windows.Forms.RadioButton()
        Me.rb411 = New System.Windows.Forms.RadioButton()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.rb812 = New System.Windows.Forms.RadioButton()
        Me.rb811 = New System.Windows.Forms.RadioButton()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.rb582 = New System.Windows.Forms.RadioButton()
        Me.rb581 = New System.Windows.Forms.RadioButton()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.rb572 = New System.Windows.Forms.RadioButton()
        Me.rb571 = New System.Windows.Forms.RadioButton()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.rb562 = New System.Windows.Forms.RadioButton()
        Me.rb561 = New System.Windows.Forms.RadioButton()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.rb552 = New System.Windows.Forms.RadioButton()
        Me.rb551 = New System.Windows.Forms.RadioButton()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.rb542 = New System.Windows.Forms.RadioButton()
        Me.rb541 = New System.Windows.Forms.RadioButton()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.rb532 = New System.Windows.Forms.RadioButton()
        Me.rb531 = New System.Windows.Forms.RadioButton()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.rb522 = New System.Windows.Forms.RadioButton()
        Me.rb521 = New System.Windows.Forms.RadioButton()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.rb512 = New System.Windows.Forms.RadioButton()
        Me.rb511 = New System.Windows.Forms.RadioButton()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.rb5112 = New System.Windows.Forms.RadioButton()
        Me.rb5111 = New System.Windows.Forms.RadioButton()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.rb5102 = New System.Windows.Forms.RadioButton()
        Me.rb5101 = New System.Windows.Forms.RadioButton()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.rb592 = New System.Windows.Forms.RadioButton()
        Me.rb591 = New System.Windows.Forms.RadioButton()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.rb5142 = New System.Windows.Forms.RadioButton()
        Me.rb5141 = New System.Windows.Forms.RadioButton()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.rb5132 = New System.Windows.Forms.RadioButton()
        Me.rb5131 = New System.Windows.Forms.RadioButton()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.rb5122 = New System.Windows.Forms.RadioButton()
        Me.rb5121 = New System.Windows.Forms.RadioButton()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.rb5152 = New System.Windows.Forms.RadioButton()
        Me.rb5151 = New System.Windows.Forms.RadioButton()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.rb9102 = New System.Windows.Forms.RadioButton()
        Me.rb9101 = New System.Windows.Forms.RadioButton()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.rb992 = New System.Windows.Forms.RadioButton()
        Me.rb991 = New System.Windows.Forms.RadioButton()
        Me.Panel49 = New System.Windows.Forms.Panel()
        Me.rb982 = New System.Windows.Forms.RadioButton()
        Me.rb981 = New System.Windows.Forms.RadioButton()
        Me.Panel50 = New System.Windows.Forms.Panel()
        Me.rb972 = New System.Windows.Forms.RadioButton()
        Me.rb971 = New System.Windows.Forms.RadioButton()
        Me.Panel51 = New System.Windows.Forms.Panel()
        Me.rb962 = New System.Windows.Forms.RadioButton()
        Me.rb961 = New System.Windows.Forms.RadioButton()
        Me.Panel52 = New System.Windows.Forms.Panel()
        Me.rb952 = New System.Windows.Forms.RadioButton()
        Me.rb951 = New System.Windows.Forms.RadioButton()
        Me.Panel53 = New System.Windows.Forms.Panel()
        Me.rb942 = New System.Windows.Forms.RadioButton()
        Me.rb941 = New System.Windows.Forms.RadioButton()
        Me.Panel54 = New System.Windows.Forms.Panel()
        Me.rb932 = New System.Windows.Forms.RadioButton()
        Me.rb931 = New System.Windows.Forms.RadioButton()
        Me.Panel55 = New System.Windows.Forms.Panel()
        Me.rb922 = New System.Windows.Forms.RadioButton()
        Me.rb921 = New System.Windows.Forms.RadioButton()
        Me.Panel56 = New System.Windows.Forms.Panel()
        Me.rb912 = New System.Windows.Forms.RadioButton()
        Me.rb911 = New System.Windows.Forms.RadioButton()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Panel57 = New System.Windows.Forms.Panel()
        Me.rbEpostNei = New System.Windows.Forms.RadioButton()
        Me.rbEpostJa = New System.Windows.Forms.RadioButton()
        Me.Panel58 = New System.Windows.Forms.Panel()
        Me.rbSMSNei = New System.Windows.Forms.RadioButton()
        Me.rbSMSJa = New System.Windows.Forms.RadioButton()
        Me.Panel59 = New System.Windows.Forms.Panel()
        Me.rb1102 = New System.Windows.Forms.RadioButton()
        Me.rb3101 = New System.Windows.Forms.RadioButton()
        Me.Panel60 = New System.Windows.Forms.Panel()
        Me.rb392 = New System.Windows.Forms.RadioButton()
        Me.rb391 = New System.Windows.Forms.RadioButton()
        Me.btnInfo = New System.Windows.Forms.Button()
        Me.lblDato = New System.Windows.Forms.Label()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Panel61 = New System.Windows.Forms.Panel()
        Me.rb152 = New System.Windows.Forms.RadioButton()
        Me.rb151 = New System.Windows.Forms.RadioButton()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Panel62 = New System.Windows.Forms.Panel()
        Me.rb162 = New System.Windows.Forms.RadioButton()
        Me.rb161 = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.chkSjekk = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblFornavn = New System.Windows.Forms.Label()
        Me.lblEtternavn = New System.Windows.Forms.Label()
        Me.label4030 = New System.Windows.Forms.Label()
        Me.lblPersonID = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel33.SuspendLayout()
        Me.Panel34.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.Panel36.SuspendLayout()
        Me.Panel37.SuspendLayout()
        Me.Panel38.SuspendLayout()
        Me.Panel39.SuspendLayout()
        Me.Panel40.SuspendLayout()
        Me.Panel41.SuspendLayout()
        Me.Panel42.SuspendLayout()
        Me.Panel43.SuspendLayout()
        Me.Panel44.SuspendLayout()
        Me.Panel45.SuspendLayout()
        Me.Panel48.SuspendLayout()
        Me.Panel46.SuspendLayout()
        Me.Panel47.SuspendLayout()
        Me.Panel49.SuspendLayout()
        Me.Panel50.SuspendLayout()
        Me.Panel51.SuspendLayout()
        Me.Panel52.SuspendLayout()
        Me.Panel53.SuspendLayout()
        Me.Panel54.SuspendLayout()
        Me.Panel55.SuspendLayout()
        Me.Panel56.SuspendLayout()
        Me.Panel57.SuspendLayout()
        Me.Panel58.SuspendLayout()
        Me.Panel59.SuspendLayout()
        Me.Panel60.SuspendLayout()
        Me.Panel61.SuspendLayout()
        Me.Panel62.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(199, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(346, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Spørreskjema for blodgivere"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(55, 229)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Fyll ut"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(55, 332)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(193, 13)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Har du fått informasjon om blodgivning?"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(301, 316)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(18, 13)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "Ja"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(321, 316)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(23, 13)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Nei"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(55, 316)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(101, 13)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "Vennligst besvar"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(55, 354)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(109, 13)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "Føler du deg frisk nå?"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(55, 378)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(176, 13)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Hvis du har gitt blod tidligere, har du"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(55, 391)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(210, 13)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "vært frisk i perioden fra forrige blodgivning?"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(55, 418)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(124, 13)
        Me.Label17.TabIndex = 33
        Me.Label17.Text = "Veier du 50 kg eller mer?"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(55, 503)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(201, 13)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "Har du i løpet av de siste fire uker"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(55, 529)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(85, 13)
        Me.Label19.TabIndex = 38
        Me.Label19.Text = "Brukt medisiner?"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(55, 619)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(171, 13)
        Me.Label21.TabIndex = 40
        Me.Label21.Text = "Vært hos tannlege eller tannpleier?"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(55, 596)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(71, 13)
        Me.Label22.TabIndex = 41
        Me.Label22.Text = "Fått vaksine?"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(55, 573)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(90, 13)
        Me.Label23.TabIndex = 42
        Me.Label23.Text = "Hatt løs avføring?"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(55, 551)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(125, 13)
        Me.Label24.TabIndex = 43
        Me.Label24.Text = "Vært syk eller hatt feber?"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(360, 316)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(232, 13)
        Me.Label25.TabIndex = 56
        Me.Label25.Text = "Har du i løpet av de siste seks måneder"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(360, 332)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(210, 13)
        Me.Label26.TabIndex = 57
        Me.Label26.Text = "Vært til undersøkelse eller på sykehus, eller"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(360, 345)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(164, 13)
        Me.Label27.TabIndex = 58
        Me.Label27.Text = "fått behandling for noen sykdom?"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(631, 316)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(23, 13)
        Me.Label28.TabIndex = 62
        Me.Label28.Text = "Nei"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(607, 316)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(18, 13)
        Me.Label29.TabIndex = 61
        Me.Label29.Text = "Ja"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(360, 368)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(149, 13)
        Me.Label30.TabIndex = 63
        Me.Label30.Text = "Fått behandling med sprøyter?"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(360, 391)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(210, 13)
        Me.Label31.TabIndex = 66
        Me.Label31.Text = "Hatt kjønnssykdom, eller fått behandling for"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(360, 404)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(80, 13)
        Me.Label32.TabIndex = 67
        Me.Label32.Text = "kjønnssykdom?"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(360, 429)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(227, 13)
        Me.Label33.TabIndex = 70
        Me.Label33.Text = "Hatt seksuell kontakt med en person med HIV-"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(360, 442)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(192, 13)
        Me.Label34.TabIndex = 71
        Me.Label34.Text = "infeksjon eller hepatitt B eller hepatitt C,"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(360, 455)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(213, 13)
        Me.Label35.TabIndex = 72
        Me.Label35.Text = "eller med en person som har hatt positiv test"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(360, 468)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(147, 13)
        Me.Label36.TabIndex = 73
        Me.Label36.Text = "for en av disse sykdommene?"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(360, 490)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(235, 13)
        Me.Label37.TabIndex = 76
        Me.Label37.Text = "Hatt seksuell kontakt med en person som bruker"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(360, 503)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(207, 13)
        Me.Label38.TabIndex = 77
        Me.Label38.Text = "eller har brukt dopingmidler eller narkotiske"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(360, 516)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(102, 13)
        Me.Label39.TabIndex = 78
        Me.Label39.Text = "midler som sprøyter?"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(360, 535)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(207, 13)
        Me.Label40.TabIndex = 81
        Me.Label40.Text = "Hatt seksuell kontakt med prostituerte eller"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(363, 548)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(104, 13)
        Me.Label41.TabIndex = 82
        Me.Label41.Text = "tidligere prostituerte?"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(363, 570)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(224, 13)
        Me.Label42.TabIndex = 85
        Me.Label42.Text = "Blitt tatovert, fått piercing eller tatt hull i ørene?"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(55, 950)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(133, 13)
        Me.Label57.TabIndex = 222
        Me.Label57.Text = "Vært utenfor Vest-Europa?"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(55, 927)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(119, 13)
        Me.Label56.TabIndex = 219
        Me.Label56.Text = "Hatt ny seksualpartner?"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(55, 889)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(220, 13)
        Me.Label54.TabIndex = 216
        Me.Label54.Text = "Hatt seksuell kontakt med en person som har"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(55, 902)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(215, 13)
        Me.Label55.TabIndex = 215
        Me.Label55.Text = "fått blod eller blodprodukter utenfor Norden?"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(55, 866)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(191, 13)
        Me.Label53.TabIndex = 212
        Me.Label53.Text = "Hatt sekspartner som har vært i Afrika?"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(55, 831)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(210, 13)
        Me.Label51.TabIndex = 211
        Me.Label51.Text = "Hatt seksualpartner som har bodd mer enn "
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(55, 844)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(224, 13)
        Me.Label52.TabIndex = 210
        Me.Label52.Text = "ett år sammenhengende utenfor Vest-Europa?"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(55, 808)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(82, 13)
        Me.Label50.TabIndex = 209
        Me.Label50.Text = "Blitt bitt av flått?"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(55, 714)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(214, 13)
        Me.Label43.TabIndex = 196
        Me.Label43.Text = "Stukket eller skåret deg på gjenstander som"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(55, 727)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(217, 13)
        Me.Label44.TabIndex = 195
        Me.Label44.Text = "var forurenset med blod eller kroppsvæsker?"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(55, 750)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(194, 13)
        Me.Label45.TabIndex = 194
        Me.Label45.Text = "Bodd i samme husstand som en person "
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(55, 763)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(98, 13)
        Me.Label46.TabIndex = 193
        Me.Label46.Text = "som har hepatitt B?"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(55, 785)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(209, 13)
        Me.Label47.TabIndex = 192
        Me.Label47.Text = "Fått blodsøl på slimhinner eller skadet hud?"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(55, 692)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(88, 13)
        Me.Label48.TabIndex = 191
        Me.Label48.Text = "Fått akupunktur?"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(55, 666)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(232, 13)
        Me.Label49.TabIndex = 190
        Me.Label49.Text = "Har du i løpet av de siste seks måneder"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(363, 637)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(123, 13)
        Me.Label58.TabIndex = 225
        Me.Label58.Text = "Besvares av kvinner"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(363, 663)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(70, 13)
        Me.Label59.TabIndex = 226
        Me.Label59.Text = "Er du gravid?"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(363, 685)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(201, 13)
        Me.Label60.TabIndex = 236
        Me.Label60.Text = "Har du vært gravid i løpet av de siste tolv"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(363, 698)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(143, 13)
        Me.Label61.TabIndex = 235
        Me.Label61.Text = "måneder, eller ammer du nå?"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(363, 721)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(179, 13)
        Me.Label62.TabIndex = 238
        Me.Label62.Text = "Har du gitt blod tidligere, har du vært"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(363, 734)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(159, 13)
        Me.Label63.TabIndex = 237
        Me.Label63.Text = "gravid siden forrige blodgivning?"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(363, 782)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(193, 13)
        Me.Label64.TabIndex = 241
        Me.Label64.Text = "hatt seksuell kontakt med andre menn?"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(363, 769)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(224, 13)
        Me.Label65.TabIndex = 240
        Me.Label65.Text = "seksuell kontakt med en mann som du vet har"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(363, 756)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(214, 13)
        Me.Label66.TabIndex = 239
        Me.Label66.Text = "Har du i løpet av de siste seks måneder hatt"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(363, 815)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(111, 13)
        Me.Label67.TabIndex = 242
        Me.Label67.Text = "Besvares av menn"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(321, 503)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(23, 13)
        Me.Label68.TabIndex = 244
        Me.Label68.Text = "Nei"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(297, 503)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(18, 13)
        Me.Label69.TabIndex = 243
        Me.Label69.Text = "Ja"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(321, 666)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(23, 13)
        Me.Label70.TabIndex = 246
        Me.Label70.Text = "Nei"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(297, 666)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(18, 13)
        Me.Label71.TabIndex = 245
        Me.Label71.Text = "Ja"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(631, 637)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(23, 13)
        Me.Label72.TabIndex = 248
        Me.Label72.Text = "Nei"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(607, 637)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(18, 13)
        Me.Label73.TabIndex = 247
        Me.Label73.Text = "Ja"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(631, 815)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(23, 13)
        Me.Label74.TabIndex = 250
        Me.Label74.Text = "Nei"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(607, 815)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(18, 13)
        Me.Label75.TabIndex = 249
        Me.Label75.Text = "Ja"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(363, 837)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(228, 13)
        Me.Label76.TabIndex = 252
        Me.Label76.Text = "Har du hatt seksuell kontakt med andre menn?"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(55, 993)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(180, 13)
        Me.Label77.TabIndex = 255
        Me.Label77.Text = "Har du i løpet av de siste to år"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(55, 1016)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(237, 13)
        Me.Label78.TabIndex = 256
        Me.Label78.Text = "Hatt sjeldne eller alvorlige infeksjonssukdommer?"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(363, 1149)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(228, 13)
        Me.Label79.TabIndex = 288
        Me.Label79.Text = "brukes til forskning? Du er like velkommen som"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(363, 1136)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(241, 13)
        Me.Label80.TabIndex = 285
        Me.Label80.Text = "Godtar du at anonumiserte prøver av ditt blod kan"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(363, 1110)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(221, 13)
        Me.Label81.TabIndex = 284
        Me.Label81.Text = "Er du eller din mor født i Amerika sør for USA?"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(363, 1091)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(94, 13)
        Me.Label82.TabIndex = 281
        Me.Label82.Text = "fem år til sammen?"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(363, 1078)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(167, 13)
        Me.Label83.TabIndex = 280
        Me.Label83.Text = "Har du oppholdt deg i Afrika i mer "
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(363, 1056)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(237, 13)
        Me.Label84.TabIndex = 279
        Me.Label84.Text = "seks måneder i områder der malaria forekommer?"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(363, 1043)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(229, 13)
        Me.Label85.TabIndex = 276
        Me.Label85.Text = "Har du oppholdt deg sammenhengende i minst "
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(363, 1021)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(104, 13)
        Me.Label86.TabIndex = 275
        Me.Label86.Text = "malaria forekommer?"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(363, 1008)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(240, 13)
        Me.Label87.TabIndex = 274
        Me.Label87.Text = "Har du i løpet av de tre siste år vært i områder der"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Location = New System.Drawing.Point(363, 983)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(215, 13)
        Me.Label88.TabIndex = 273
        Me.Label88.Text = "til sammen i perioden mellom 1980 og 1996?"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(363, 970)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(238, 13)
        Me.Label89.TabIndex = 270
        Me.Label89.Text = "Har du oppholdt deg i Storbritania i mer enn ett år"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(363, 950)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(129, 13)
        Me.Label90.TabIndex = 269
        Me.Label90.Text = "sykdom eller variant CJD?"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(363, 934)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(234, 13)
        Me.Label91.TabIndex = 266
        Me.Label91.Text = "Har du eller noen i familien hatt Creutzfeldt-jakob"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(631, 873)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(23, 13)
        Me.Label92.TabIndex = 265
        Me.Label92.Text = "Nei"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Location = New System.Drawing.Point(611, 873)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(18, 13)
        Me.Label93.TabIndex = 264
        Me.Label93.Text = "Ja"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(363, 911)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(144, 13)
        Me.Label94.TabIndex = 261
        Me.Label94.Text = "ganger de siste 12 måneder?"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(363, 898)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(173, 13)
        Me.Label95.TabIndex = 260
        Me.Label95.Text = "Har du brukt narkotika en eller flere"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(363, 873)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(77, 13)
        Me.Label96.TabIndex = 259
        Me.Label96.Text = "Besvar også"
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(363, 1162)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(240, 13)
        Me.Label97.TabIndex = 291
        Me.Label97.Text = "blodgiver enten du svarer ja eller nei. Blodbanken"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Location = New System.Drawing.Point(363, 1175)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(249, 13)
        Me.Label98.TabIndex = 292
        Me.Label98.Text = "kan gi informasjon om aktuelle forskningsprosjekter."
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(363, 1211)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(54, 13)
        Me.Label99.TabIndex = 296
        Me.Label99.Text = "måneder?"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(363, 1198)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(219, 13)
        Me.Label100.TabIndex = 295
        Me.Label100.Text = "Har du deltatt i medikamentforsøk de siste 12"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(363, 1246)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(124, 13)
        Me.Label101.TabIndex = 300
        Me.Label101.Text = "for legemiddelproduksjon"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(363, 1233)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(232, 13)
        Me.Label102.TabIndex = 299
        Me.Label102.Text = "Jeg samtykker i at mitt plasma føres ut av Norge"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(55, 1056)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(223, 13)
        Me.Label103.TabIndex = 303
        Me.Label103.Text = "Har du på noe tidspunkt gjennom livet"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Location = New System.Drawing.Point(321, 993)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(23, 13)
        Me.Label104.TabIndex = 305
        Me.Label104.Text = "Nei"
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Location = New System.Drawing.Point(297, 993)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(18, 13)
        Me.Label105.TabIndex = 304
        Me.Label105.Text = "Ja"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Location = New System.Drawing.Point(321, 1056)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(23, 13)
        Me.Label106.TabIndex = 307
        Me.Label106.Text = "Nei"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(297, 1056)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(18, 13)
        Me.Label107.TabIndex = 306
        Me.Label107.Text = "Ja"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Location = New System.Drawing.Point(55, 1079)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(184, 13)
        Me.Label108.TabIndex = 308
        Me.Label108.Text = "Hatt hjerte-, lever, eller lungesykdom?"
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(55, 1104)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(57, 13)
        Me.Label109.TabIndex = 311
        Me.Label109.Text = "Hatt kreft?"
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Location = New System.Drawing.Point(55, 1126)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(119, 13)
        Me.Label110.TabIndex = 314
        Me.Label110.Text = "Hatt blødningstendens?"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(55, 1149)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(172, 13)
        Me.Label111.TabIndex = 317
        Me.Label111.Text = "Hatt allergi mot mat eller medisiner?"
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Location = New System.Drawing.Point(55, 1171)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(69, 13)
        Me.Label112.TabIndex = 320
        Me.Label112.Text = "Hatt malaria?"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(55, 1197)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(113, 13)
        Me.Label113.TabIndex = 323
        Me.Label113.Text = "Hatt tropesykdommer?"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Location = New System.Drawing.Point(55, 1223)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(230, 13)
        Me.Label114.TabIndex = 326
        Me.Label114.Text = "Hatt hepatitt (gulsott), HIV-infeksjon eller AIDS?"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Location = New System.Drawing.Point(55, 1246)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(239, 13)
        Me.Label115.TabIndex = 329
        Me.Label115.Text = "Hatt positiv prøve for Hepatitt eller HIV-infeksjon?"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Location = New System.Drawing.Point(55, 1270)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(101, 13)
        Me.Label116.TabIndex = 332
        Me.Label116.Text = "Fått blodoverføring?"
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(55, 1294)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(95, 13)
        Me.Label117.TabIndex = 335
        Me.Label117.Text = "Fått veksthormon?"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(55, 1317)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(136, 13)
        Me.Label118.TabIndex = 338
        Me.Label118.Text = "Fått hornhinnetransplantat?"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Location = New System.Drawing.Point(55, 1340)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(60, 13)
        Me.Label119.TabIndex = 341
        Me.Label119.Text = "Hatt syfilis?"
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(55, 1362)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(213, 13)
        Me.Label120.TabIndex = 344
        Me.Label120.Text = "Hatt alvorlig sykdom som ikke er nevnt her?"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Location = New System.Drawing.Point(55, 1399)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(72, 13)
        Me.Label121.TabIndex = 348
        Me.Label121.Text = "som sprøyter?"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Location = New System.Drawing.Point(55, 1386)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(198, 13)
        Me.Label122.TabIndex = 347
        Me.Label122.Text = "Brukt dopingmidler eller narkotiske midler"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Location = New System.Drawing.Point(55, 1436)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(44, 13)
        Me.Label123.TabIndex = 352
        Me.Label123.Text = "for sex?"
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Location = New System.Drawing.Point(55, 1423)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(214, 13)
        Me.Label124.TabIndex = 351
        Me.Label124.Text = "Mottat penger eller narkotika som gjenytelse"
        '
        'btnSendInn
        '
        Me.btnSendInn.Location = New System.Drawing.Point(281, 1559)
        Me.btnSendInn.Name = "btnSendInn"
        Me.btnSendInn.Size = New System.Drawing.Size(158, 23)
        Me.btnSendInn.TabIndex = 356
        Me.btnSendInn.Text = "Send inn Egenærklering"
        Me.btnSendInn.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rb612)
        Me.Panel1.Controls.Add(Me.rb611)
        Me.Panel1.Location = New System.Drawing.Point(608, 332)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(46, 19)
        Me.Panel1.TabIndex = 367
        '
        'rb612
        '
        Me.rb612.AutoSize = True
        Me.rb612.Location = New System.Drawing.Point(29, 3)
        Me.rb612.Name = "rb612"
        Me.rb612.Size = New System.Drawing.Size(14, 13)
        Me.rb612.TabIndex = 4
        Me.rb612.TabStop = True
        Me.rb612.UseVisualStyleBackColor = True
        '
        'rb611
        '
        Me.rb611.AutoSize = True
        Me.rb611.Location = New System.Drawing.Point(5, 3)
        Me.rb611.Name = "rb611"
        Me.rb611.Size = New System.Drawing.Size(14, 13)
        Me.rb611.TabIndex = 3
        Me.rb611.TabStop = True
        Me.rb611.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.rb622)
        Me.Panel2.Controls.Add(Me.rb621)
        Me.Panel2.Location = New System.Drawing.Point(608, 368)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(46, 19)
        Me.Panel2.TabIndex = 368
        '
        'rb622
        '
        Me.rb622.AutoSize = True
        Me.rb622.Location = New System.Drawing.Point(29, 3)
        Me.rb622.Name = "rb622"
        Me.rb622.Size = New System.Drawing.Size(14, 13)
        Me.rb622.TabIndex = 4
        Me.rb622.TabStop = True
        Me.rb622.UseVisualStyleBackColor = True
        '
        'rb621
        '
        Me.rb621.AutoSize = True
        Me.rb621.Location = New System.Drawing.Point(5, 3)
        Me.rb621.Name = "rb621"
        Me.rb621.Size = New System.Drawing.Size(14, 13)
        Me.rb621.TabIndex = 3
        Me.rb621.TabStop = True
        Me.rb621.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.rb642)
        Me.Panel3.Controls.Add(Me.rb641)
        Me.Panel3.Location = New System.Drawing.Point(608, 436)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(46, 19)
        Me.Panel3.TabIndex = 369
        '
        'rb642
        '
        Me.rb642.AutoSize = True
        Me.rb642.Location = New System.Drawing.Point(29, 3)
        Me.rb642.Name = "rb642"
        Me.rb642.Size = New System.Drawing.Size(14, 13)
        Me.rb642.TabIndex = 4
        Me.rb642.TabStop = True
        Me.rb642.UseVisualStyleBackColor = True
        '
        'rb641
        '
        Me.rb641.AutoSize = True
        Me.rb641.Location = New System.Drawing.Point(5, 3)
        Me.rb641.Name = "rb641"
        Me.rb641.Size = New System.Drawing.Size(14, 13)
        Me.rb641.TabIndex = 3
        Me.rb641.TabStop = True
        Me.rb641.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.rb652)
        Me.Panel4.Controls.Add(Me.rb651)
        Me.Panel4.Location = New System.Drawing.Point(608, 497)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(46, 19)
        Me.Panel4.TabIndex = 370
        '
        'rb652
        '
        Me.rb652.AutoSize = True
        Me.rb652.Location = New System.Drawing.Point(29, 3)
        Me.rb652.Name = "rb652"
        Me.rb652.Size = New System.Drawing.Size(14, 13)
        Me.rb652.TabIndex = 4
        Me.rb652.TabStop = True
        Me.rb652.UseVisualStyleBackColor = True
        '
        'rb651
        '
        Me.rb651.AutoSize = True
        Me.rb651.Location = New System.Drawing.Point(5, 3)
        Me.rb651.Name = "rb651"
        Me.rb651.Size = New System.Drawing.Size(14, 13)
        Me.rb651.TabIndex = 3
        Me.rb651.TabStop = True
        Me.rb651.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.rb662)
        Me.Panel5.Controls.Add(Me.rb661)
        Me.Panel5.Location = New System.Drawing.Point(608, 542)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(46, 19)
        Me.Panel5.TabIndex = 371
        '
        'rb662
        '
        Me.rb662.AutoSize = True
        Me.rb662.Location = New System.Drawing.Point(29, 3)
        Me.rb662.Name = "rb662"
        Me.rb662.Size = New System.Drawing.Size(14, 13)
        Me.rb662.TabIndex = 4
        Me.rb662.TabStop = True
        Me.rb662.UseVisualStyleBackColor = True
        '
        'rb661
        '
        Me.rb661.AutoSize = True
        Me.rb661.Location = New System.Drawing.Point(5, 3)
        Me.rb661.Name = "rb661"
        Me.rb661.Size = New System.Drawing.Size(14, 13)
        Me.rb661.TabIndex = 3
        Me.rb661.TabStop = True
        Me.rb661.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.rb672)
        Me.Panel6.Controls.Add(Me.rb671)
        Me.Panel6.Location = New System.Drawing.Point(608, 570)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(46, 19)
        Me.Panel6.TabIndex = 372
        '
        'rb672
        '
        Me.rb672.AutoSize = True
        Me.rb672.Location = New System.Drawing.Point(29, 3)
        Me.rb672.Name = "rb672"
        Me.rb672.Size = New System.Drawing.Size(14, 13)
        Me.rb672.TabIndex = 4
        Me.rb672.TabStop = True
        Me.rb672.UseVisualStyleBackColor = True
        '
        'rb671
        '
        Me.rb671.AutoSize = True
        Me.rb671.Location = New System.Drawing.Point(5, 3)
        Me.rb671.Name = "rb671"
        Me.rb671.Size = New System.Drawing.Size(14, 13)
        Me.rb671.TabIndex = 3
        Me.rb671.TabStop = True
        Me.rb671.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.rb632)
        Me.Panel7.Controls.Add(Me.rb631)
        Me.Panel7.Location = New System.Drawing.Point(608, 393)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(46, 19)
        Me.Panel7.TabIndex = 373
        '
        'rb632
        '
        Me.rb632.AutoSize = True
        Me.rb632.Location = New System.Drawing.Point(29, 3)
        Me.rb632.Name = "rb632"
        Me.rb632.Size = New System.Drawing.Size(14, 13)
        Me.rb632.TabIndex = 4
        Me.rb632.TabStop = True
        Me.rb632.UseVisualStyleBackColor = True
        '
        'rb631
        '
        Me.rb631.AutoSize = True
        Me.rb631.Location = New System.Drawing.Point(5, 3)
        Me.rb631.Name = "rb631"
        Me.rb631.Size = New System.Drawing.Size(14, 13)
        Me.rb631.TabIndex = 3
        Me.rb631.TabStop = True
        Me.rb631.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.rb132)
        Me.Panel8.Controls.Add(Me.rb131)
        Me.Panel8.Location = New System.Drawing.Point(298, 385)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(46, 19)
        Me.Panel8.TabIndex = 377
        '
        'rb132
        '
        Me.rb132.AutoSize = True
        Me.rb132.Location = New System.Drawing.Point(29, 3)
        Me.rb132.Name = "rb132"
        Me.rb132.Size = New System.Drawing.Size(14, 13)
        Me.rb132.TabIndex = 4
        Me.rb132.TabStop = True
        Me.rb132.UseVisualStyleBackColor = True
        '
        'rb131
        '
        Me.rb131.AutoSize = True
        Me.rb131.Location = New System.Drawing.Point(5, 3)
        Me.rb131.Name = "rb131"
        Me.rb131.Size = New System.Drawing.Size(14, 13)
        Me.rb131.TabIndex = 3
        Me.rb131.TabStop = True
        Me.rb131.UseVisualStyleBackColor = True
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.rb142)
        Me.Panel9.Controls.Add(Me.rb141)
        Me.Panel9.Location = New System.Drawing.Point(298, 418)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(46, 19)
        Me.Panel9.TabIndex = 376
        '
        'rb142
        '
        Me.rb142.AutoSize = True
        Me.rb142.Location = New System.Drawing.Point(29, 3)
        Me.rb142.Name = "rb142"
        Me.rb142.Size = New System.Drawing.Size(14, 13)
        Me.rb142.TabIndex = 4
        Me.rb142.TabStop = True
        Me.rb142.UseVisualStyleBackColor = True
        '
        'rb141
        '
        Me.rb141.AutoSize = True
        Me.rb141.Location = New System.Drawing.Point(5, 3)
        Me.rb141.Name = "rb141"
        Me.rb141.Size = New System.Drawing.Size(14, 13)
        Me.rb141.TabIndex = 3
        Me.rb141.TabStop = True
        Me.rb141.UseVisualStyleBackColor = True
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.rb122)
        Me.Panel10.Controls.Add(Me.rb121)
        Me.Panel10.Location = New System.Drawing.Point(298, 354)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(46, 19)
        Me.Panel10.TabIndex = 375
        '
        'rb122
        '
        Me.rb122.AutoSize = True
        Me.rb122.Location = New System.Drawing.Point(29, 3)
        Me.rb122.Name = "rb122"
        Me.rb122.Size = New System.Drawing.Size(14, 13)
        Me.rb122.TabIndex = 4
        Me.rb122.TabStop = True
        Me.rb122.UseVisualStyleBackColor = True
        '
        'rb121
        '
        Me.rb121.AutoSize = True
        Me.rb121.Location = New System.Drawing.Point(5, 3)
        Me.rb121.Name = "rb121"
        Me.rb121.Size = New System.Drawing.Size(14, 13)
        Me.rb121.TabIndex = 3
        Me.rb121.TabStop = True
        Me.rb121.UseVisualStyleBackColor = True
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.rb112)
        Me.Panel11.Controls.Add(Me.rb111)
        Me.Panel11.Location = New System.Drawing.Point(298, 332)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(46, 19)
        Me.Panel11.TabIndex = 374
        '
        'rb112
        '
        Me.rb112.AutoSize = True
        Me.rb112.Location = New System.Drawing.Point(29, 3)
        Me.rb112.Name = "rb112"
        Me.rb112.Size = New System.Drawing.Size(14, 13)
        Me.rb112.TabIndex = 4
        Me.rb112.TabStop = True
        Me.rb112.UseVisualStyleBackColor = True
        '
        'rb111
        '
        Me.rb111.AutoSize = True
        Me.rb111.Location = New System.Drawing.Point(5, 3)
        Me.rb111.Name = "rb111"
        Me.rb111.Size = New System.Drawing.Size(14, 13)
        Me.rb111.TabIndex = 3
        Me.rb111.TabStop = True
        Me.rb111.UseVisualStyleBackColor = True
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.rb232)
        Me.Panel12.Controls.Add(Me.rb231)
        Me.Panel12.Location = New System.Drawing.Point(298, 570)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(46, 19)
        Me.Panel12.TabIndex = 377
        '
        'rb232
        '
        Me.rb232.AutoSize = True
        Me.rb232.Location = New System.Drawing.Point(29, 3)
        Me.rb232.Name = "rb232"
        Me.rb232.Size = New System.Drawing.Size(14, 13)
        Me.rb232.TabIndex = 4
        Me.rb232.TabStop = True
        Me.rb232.UseVisualStyleBackColor = True
        '
        'rb231
        '
        Me.rb231.AutoSize = True
        Me.rb231.Location = New System.Drawing.Point(5, 3)
        Me.rb231.Name = "rb231"
        Me.rb231.Size = New System.Drawing.Size(14, 13)
        Me.rb231.TabIndex = 3
        Me.rb231.TabStop = True
        Me.rb231.UseVisualStyleBackColor = True
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.rb222)
        Me.Panel14.Controls.Add(Me.rb221)
        Me.Panel14.Location = New System.Drawing.Point(298, 548)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(46, 19)
        Me.Panel14.TabIndex = 375
        '
        'rb222
        '
        Me.rb222.AutoSize = True
        Me.rb222.Location = New System.Drawing.Point(29, 3)
        Me.rb222.Name = "rb222"
        Me.rb222.Size = New System.Drawing.Size(14, 13)
        Me.rb222.TabIndex = 4
        Me.rb222.TabStop = True
        Me.rb222.UseVisualStyleBackColor = True
        '
        'rb221
        '
        Me.rb221.AutoSize = True
        Me.rb221.Location = New System.Drawing.Point(5, 3)
        Me.rb221.Name = "rb221"
        Me.rb221.Size = New System.Drawing.Size(14, 13)
        Me.rb221.TabIndex = 3
        Me.rb221.TabStop = True
        Me.rb221.UseVisualStyleBackColor = True
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.rb212)
        Me.Panel15.Controls.Add(Me.rb211)
        Me.Panel15.Location = New System.Drawing.Point(298, 526)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(46, 19)
        Me.Panel15.TabIndex = 374
        '
        'rb212
        '
        Me.rb212.AutoSize = True
        Me.rb212.Location = New System.Drawing.Point(29, 3)
        Me.rb212.Name = "rb212"
        Me.rb212.Size = New System.Drawing.Size(14, 13)
        Me.rb212.TabIndex = 4
        Me.rb212.TabStop = True
        Me.rb212.UseVisualStyleBackColor = True
        '
        'rb211
        '
        Me.rb211.AutoSize = True
        Me.rb211.Location = New System.Drawing.Point(5, 3)
        Me.rb211.Name = "rb211"
        Me.rb211.Size = New System.Drawing.Size(14, 13)
        Me.rb211.TabIndex = 3
        Me.rb211.TabStop = True
        Me.rb211.UseVisualStyleBackColor = True
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.rb252)
        Me.Panel16.Controls.Add(Me.rb251)
        Me.Panel16.Location = New System.Drawing.Point(298, 617)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(46, 19)
        Me.Panel16.TabIndex = 379
        '
        'rb252
        '
        Me.rb252.AutoSize = True
        Me.rb252.Location = New System.Drawing.Point(29, 3)
        Me.rb252.Name = "rb252"
        Me.rb252.Size = New System.Drawing.Size(14, 13)
        Me.rb252.TabIndex = 4
        Me.rb252.TabStop = True
        Me.rb252.UseVisualStyleBackColor = True
        '
        'rb251
        '
        Me.rb251.AutoSize = True
        Me.rb251.Location = New System.Drawing.Point(5, 3)
        Me.rb251.Name = "rb251"
        Me.rb251.Size = New System.Drawing.Size(14, 13)
        Me.rb251.TabIndex = 3
        Me.rb251.TabStop = True
        Me.rb251.UseVisualStyleBackColor = True
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.rb242)
        Me.Panel17.Controls.Add(Me.rb241)
        Me.Panel17.Location = New System.Drawing.Point(298, 595)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(46, 19)
        Me.Panel17.TabIndex = 378
        '
        'rb242
        '
        Me.rb242.AutoSize = True
        Me.rb242.Location = New System.Drawing.Point(29, 3)
        Me.rb242.Name = "rb242"
        Me.rb242.Size = New System.Drawing.Size(14, 13)
        Me.rb242.TabIndex = 4
        Me.rb242.TabStop = True
        Me.rb242.UseVisualStyleBackColor = True
        '
        'rb241
        '
        Me.rb241.AutoSize = True
        Me.rb241.Location = New System.Drawing.Point(5, 3)
        Me.rb241.Name = "rb241"
        Me.rb241.Size = New System.Drawing.Size(14, 13)
        Me.rb241.TabIndex = 3
        Me.rb241.TabStop = True
        Me.rb241.UseVisualStyleBackColor = True
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.rb332)
        Me.Panel18.Controls.Add(Me.rb331)
        Me.Panel18.Location = New System.Drawing.Point(298, 757)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(46, 19)
        Me.Panel18.TabIndex = 383
        '
        'rb332
        '
        Me.rb332.AutoSize = True
        Me.rb332.Location = New System.Drawing.Point(29, 3)
        Me.rb332.Name = "rb332"
        Me.rb332.Size = New System.Drawing.Size(14, 13)
        Me.rb332.TabIndex = 4
        Me.rb332.TabStop = True
        Me.rb332.UseVisualStyleBackColor = True
        '
        'rb331
        '
        Me.rb331.AutoSize = True
        Me.rb331.Location = New System.Drawing.Point(5, 3)
        Me.rb331.Name = "rb331"
        Me.rb331.Size = New System.Drawing.Size(14, 13)
        Me.rb331.TabIndex = 3
        Me.rb331.TabStop = True
        Me.rb331.UseVisualStyleBackColor = True
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.rb322)
        Me.Panel19.Controls.Add(Me.rb321)
        Me.Panel19.Location = New System.Drawing.Point(298, 721)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(46, 19)
        Me.Panel19.TabIndex = 382
        '
        'rb322
        '
        Me.rb322.AutoSize = True
        Me.rb322.Location = New System.Drawing.Point(29, 3)
        Me.rb322.Name = "rb322"
        Me.rb322.Size = New System.Drawing.Size(14, 13)
        Me.rb322.TabIndex = 4
        Me.rb322.TabStop = True
        Me.rb322.UseVisualStyleBackColor = True
        '
        'rb321
        '
        Me.rb321.AutoSize = True
        Me.rb321.Location = New System.Drawing.Point(5, 3)
        Me.rb321.Name = "rb321"
        Me.rb321.Size = New System.Drawing.Size(14, 13)
        Me.rb321.TabIndex = 3
        Me.rb321.TabStop = True
        Me.rb321.UseVisualStyleBackColor = True
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.rb312)
        Me.Panel20.Controls.Add(Me.rb311)
        Me.Panel20.Location = New System.Drawing.Point(298, 689)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(46, 19)
        Me.Panel20.TabIndex = 381
        '
        'rb312
        '
        Me.rb312.AutoSize = True
        Me.rb312.Location = New System.Drawing.Point(29, 3)
        Me.rb312.Name = "rb312"
        Me.rb312.Size = New System.Drawing.Size(14, 13)
        Me.rb312.TabIndex = 4
        Me.rb312.TabStop = True
        Me.rb312.UseVisualStyleBackColor = True
        '
        'rb311
        '
        Me.rb311.AutoSize = True
        Me.rb311.Location = New System.Drawing.Point(5, 3)
        Me.rb311.Name = "rb311"
        Me.rb311.Size = New System.Drawing.Size(14, 13)
        Me.rb311.TabIndex = 3
        Me.rb311.TabStop = True
        Me.rb311.UseVisualStyleBackColor = True
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.rb362)
        Me.Panel21.Controls.Add(Me.rb361)
        Me.Panel21.Location = New System.Drawing.Point(298, 838)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(46, 19)
        Me.Panel21.TabIndex = 386
        '
        'rb362
        '
        Me.rb362.AutoSize = True
        Me.rb362.Location = New System.Drawing.Point(29, 3)
        Me.rb362.Name = "rb362"
        Me.rb362.Size = New System.Drawing.Size(14, 13)
        Me.rb362.TabIndex = 4
        Me.rb362.TabStop = True
        Me.rb362.UseVisualStyleBackColor = True
        '
        'rb361
        '
        Me.rb361.AutoSize = True
        Me.rb361.Location = New System.Drawing.Point(5, 3)
        Me.rb361.Name = "rb361"
        Me.rb361.Size = New System.Drawing.Size(14, 13)
        Me.rb361.TabIndex = 3
        Me.rb361.TabStop = True
        Me.rb361.UseVisualStyleBackColor = True
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.rb352)
        Me.Panel22.Controls.Add(Me.rb351)
        Me.Panel22.Location = New System.Drawing.Point(298, 807)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(46, 19)
        Me.Panel22.TabIndex = 385
        '
        'rb352
        '
        Me.rb352.AutoSize = True
        Me.rb352.Location = New System.Drawing.Point(29, 3)
        Me.rb352.Name = "rb352"
        Me.rb352.Size = New System.Drawing.Size(14, 13)
        Me.rb352.TabIndex = 4
        Me.rb352.TabStop = True
        Me.rb352.UseVisualStyleBackColor = True
        '
        'rb351
        '
        Me.rb351.AutoSize = True
        Me.rb351.Location = New System.Drawing.Point(5, 3)
        Me.rb351.Name = "rb351"
        Me.rb351.Size = New System.Drawing.Size(14, 13)
        Me.rb351.TabIndex = 3
        Me.rb351.TabStop = True
        Me.rb351.UseVisualStyleBackColor = True
        '
        'Panel23
        '
        Me.Panel23.Controls.Add(Me.rb342)
        Me.Panel23.Controls.Add(Me.rb341)
        Me.Panel23.Location = New System.Drawing.Point(298, 782)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(46, 19)
        Me.Panel23.TabIndex = 384
        '
        'rb342
        '
        Me.rb342.AutoSize = True
        Me.rb342.Location = New System.Drawing.Point(29, 3)
        Me.rb342.Name = "rb342"
        Me.rb342.Size = New System.Drawing.Size(14, 13)
        Me.rb342.TabIndex = 4
        Me.rb342.TabStop = True
        Me.rb342.UseVisualStyleBackColor = True
        '
        'rb341
        '
        Me.rb341.AutoSize = True
        Me.rb341.Location = New System.Drawing.Point(5, 3)
        Me.rb341.Name = "rb341"
        Me.rb341.Size = New System.Drawing.Size(14, 13)
        Me.rb341.TabIndex = 3
        Me.rb341.TabStop = True
        Me.rb341.UseVisualStyleBackColor = True
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.rb372)
        Me.Panel24.Controls.Add(Me.rb371)
        Me.Panel24.Location = New System.Drawing.Point(298, 863)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(46, 19)
        Me.Panel24.TabIndex = 387
        '
        'rb372
        '
        Me.rb372.AutoSize = True
        Me.rb372.Location = New System.Drawing.Point(29, 3)
        Me.rb372.Name = "rb372"
        Me.rb372.Size = New System.Drawing.Size(14, 13)
        Me.rb372.TabIndex = 4
        Me.rb372.TabStop = True
        Me.rb372.UseVisualStyleBackColor = True
        '
        'rb371
        '
        Me.rb371.AutoSize = True
        Me.rb371.Location = New System.Drawing.Point(5, 3)
        Me.rb371.Name = "rb371"
        Me.rb371.Size = New System.Drawing.Size(14, 13)
        Me.rb371.TabIndex = 3
        Me.rb371.TabStop = True
        Me.rb371.UseVisualStyleBackColor = True
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.rb382)
        Me.Panel25.Controls.Add(Me.rb381)
        Me.Panel25.Location = New System.Drawing.Point(298, 896)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(46, 19)
        Me.Panel25.TabIndex = 388
        '
        'rb382
        '
        Me.rb382.AutoSize = True
        Me.rb382.Location = New System.Drawing.Point(29, 3)
        Me.rb382.Name = "rb382"
        Me.rb382.Size = New System.Drawing.Size(14, 13)
        Me.rb382.TabIndex = 4
        Me.rb382.TabStop = True
        Me.rb382.UseVisualStyleBackColor = True
        '
        'rb381
        '
        Me.rb381.AutoSize = True
        Me.rb381.Location = New System.Drawing.Point(5, 3)
        Me.rb381.Name = "rb381"
        Me.rb381.Size = New System.Drawing.Size(14, 13)
        Me.rb381.TabIndex = 3
        Me.rb381.TabStop = True
        Me.rb381.UseVisualStyleBackColor = True
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.rb742)
        Me.Panel27.Controls.Add(Me.rb741)
        Me.Panel27.Location = New System.Drawing.Point(607, 769)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(46, 19)
        Me.Panel27.TabIndex = 392
        '
        'rb742
        '
        Me.rb742.AutoSize = True
        Me.rb742.Location = New System.Drawing.Point(29, 3)
        Me.rb742.Name = "rb742"
        Me.rb742.Size = New System.Drawing.Size(14, 13)
        Me.rb742.TabIndex = 4
        Me.rb742.TabStop = True
        Me.rb742.UseVisualStyleBackColor = True
        '
        'rb741
        '
        Me.rb741.AutoSize = True
        Me.rb741.Location = New System.Drawing.Point(5, 3)
        Me.rb741.Name = "rb741"
        Me.rb741.Size = New System.Drawing.Size(14, 13)
        Me.rb741.TabIndex = 3
        Me.rb741.TabStop = True
        Me.rb741.UseVisualStyleBackColor = True
        '
        'Panel28
        '
        Me.Panel28.Controls.Add(Me.rb732)
        Me.Panel28.Controls.Add(Me.rb731)
        Me.Panel28.Location = New System.Drawing.Point(607, 728)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(46, 19)
        Me.Panel28.TabIndex = 391
        '
        'rb732
        '
        Me.rb732.AutoSize = True
        Me.rb732.Location = New System.Drawing.Point(29, 3)
        Me.rb732.Name = "rb732"
        Me.rb732.Size = New System.Drawing.Size(14, 13)
        Me.rb732.TabIndex = 4
        Me.rb732.TabStop = True
        Me.rb732.UseVisualStyleBackColor = True
        '
        'rb731
        '
        Me.rb731.AutoSize = True
        Me.rb731.Location = New System.Drawing.Point(5, 3)
        Me.rb731.Name = "rb731"
        Me.rb731.Size = New System.Drawing.Size(14, 13)
        Me.rb731.TabIndex = 3
        Me.rb731.TabStop = True
        Me.rb731.UseVisualStyleBackColor = True
        '
        'Panel29
        '
        Me.Panel29.Controls.Add(Me.rb722)
        Me.Panel29.Controls.Add(Me.rb721)
        Me.Panel29.Location = New System.Drawing.Point(607, 692)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(46, 19)
        Me.Panel29.TabIndex = 390
        '
        'rb722
        '
        Me.rb722.AutoSize = True
        Me.rb722.Location = New System.Drawing.Point(29, 3)
        Me.rb722.Name = "rb722"
        Me.rb722.Size = New System.Drawing.Size(14, 13)
        Me.rb722.TabIndex = 4
        Me.rb722.TabStop = True
        Me.rb722.UseVisualStyleBackColor = True
        '
        'rb721
        '
        Me.rb721.AutoSize = True
        Me.rb721.Location = New System.Drawing.Point(5, 3)
        Me.rb721.Name = "rb721"
        Me.rb721.Size = New System.Drawing.Size(14, 13)
        Me.rb721.TabIndex = 3
        Me.rb721.TabStop = True
        Me.rb721.UseVisualStyleBackColor = True
        '
        'Panel30
        '
        Me.Panel30.Controls.Add(Me.rb712)
        Me.Panel30.Controls.Add(Me.rb711)
        Me.Panel30.Location = New System.Drawing.Point(607, 660)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(46, 19)
        Me.Panel30.TabIndex = 389
        '
        'rb712
        '
        Me.rb712.AutoSize = True
        Me.rb712.Location = New System.Drawing.Point(29, 3)
        Me.rb712.Name = "rb712"
        Me.rb712.Size = New System.Drawing.Size(14, 13)
        Me.rb712.TabIndex = 4
        Me.rb712.TabStop = True
        Me.rb712.UseVisualStyleBackColor = True
        '
        'rb711
        '
        Me.rb711.AutoSize = True
        Me.rb711.Location = New System.Drawing.Point(5, 3)
        Me.rb711.Name = "rb711"
        Me.rb711.Size = New System.Drawing.Size(14, 13)
        Me.rb711.TabIndex = 3
        Me.rb711.TabStop = True
        Me.rb711.UseVisualStyleBackColor = True
        '
        'Panel26
        '
        Me.Panel26.Controls.Add(Me.rb412)
        Me.Panel26.Controls.Add(Me.rb411)
        Me.Panel26.Location = New System.Drawing.Point(298, 1013)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(46, 19)
        Me.Panel26.TabIndex = 393
        '
        'rb412
        '
        Me.rb412.AutoSize = True
        Me.rb412.Location = New System.Drawing.Point(29, 3)
        Me.rb412.Name = "rb412"
        Me.rb412.Size = New System.Drawing.Size(14, 13)
        Me.rb412.TabIndex = 4
        Me.rb412.TabStop = True
        Me.rb412.UseVisualStyleBackColor = True
        '
        'rb411
        '
        Me.rb411.AutoSize = True
        Me.rb411.Location = New System.Drawing.Point(5, 3)
        Me.rb411.Name = "rb411"
        Me.rb411.Size = New System.Drawing.Size(14, 13)
        Me.rb411.TabIndex = 3
        Me.rb411.TabStop = True
        Me.rb411.UseVisualStyleBackColor = True
        '
        'Panel31
        '
        Me.Panel31.Controls.Add(Me.rb812)
        Me.Panel31.Controls.Add(Me.rb811)
        Me.Panel31.Location = New System.Drawing.Point(608, 834)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(46, 19)
        Me.Panel31.TabIndex = 389
        '
        'rb812
        '
        Me.rb812.AutoSize = True
        Me.rb812.Location = New System.Drawing.Point(29, 3)
        Me.rb812.Name = "rb812"
        Me.rb812.Size = New System.Drawing.Size(14, 13)
        Me.rb812.TabIndex = 4
        Me.rb812.TabStop = True
        Me.rb812.UseVisualStyleBackColor = True
        '
        'rb811
        '
        Me.rb811.AutoSize = True
        Me.rb811.Location = New System.Drawing.Point(5, 3)
        Me.rb811.Name = "rb811"
        Me.rb811.Size = New System.Drawing.Size(14, 13)
        Me.rb811.TabIndex = 3
        Me.rb811.TabStop = True
        Me.rb811.UseVisualStyleBackColor = True
        '
        'Panel32
        '
        Me.Panel32.Controls.Add(Me.rb582)
        Me.Panel32.Controls.Add(Me.rb581)
        Me.Panel32.Location = New System.Drawing.Point(298, 1246)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(46, 19)
        Me.Panel32.TabIndex = 401
        '
        'rb582
        '
        Me.rb582.AutoSize = True
        Me.rb582.Location = New System.Drawing.Point(29, 3)
        Me.rb582.Name = "rb582"
        Me.rb582.Size = New System.Drawing.Size(14, 13)
        Me.rb582.TabIndex = 4
        Me.rb582.TabStop = True
        Me.rb582.UseVisualStyleBackColor = True
        '
        'rb581
        '
        Me.rb581.AutoSize = True
        Me.rb581.Location = New System.Drawing.Point(5, 3)
        Me.rb581.Name = "rb581"
        Me.rb581.Size = New System.Drawing.Size(14, 13)
        Me.rb581.TabIndex = 3
        Me.rb581.TabStop = True
        Me.rb581.UseVisualStyleBackColor = True
        '
        'Panel33
        '
        Me.Panel33.Controls.Add(Me.rb572)
        Me.Panel33.Controls.Add(Me.rb571)
        Me.Panel33.Location = New System.Drawing.Point(298, 1221)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(46, 19)
        Me.Panel33.TabIndex = 400
        '
        'rb572
        '
        Me.rb572.AutoSize = True
        Me.rb572.Location = New System.Drawing.Point(29, 3)
        Me.rb572.Name = "rb572"
        Me.rb572.Size = New System.Drawing.Size(14, 13)
        Me.rb572.TabIndex = 4
        Me.rb572.TabStop = True
        Me.rb572.UseVisualStyleBackColor = True
        '
        'rb571
        '
        Me.rb571.AutoSize = True
        Me.rb571.Location = New System.Drawing.Point(5, 3)
        Me.rb571.Name = "rb571"
        Me.rb571.Size = New System.Drawing.Size(14, 13)
        Me.rb571.TabIndex = 3
        Me.rb571.TabStop = True
        Me.rb571.UseVisualStyleBackColor = True
        '
        'Panel34
        '
        Me.Panel34.Controls.Add(Me.rb562)
        Me.Panel34.Controls.Add(Me.rb561)
        Me.Panel34.Location = New System.Drawing.Point(298, 1196)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(46, 19)
        Me.Panel34.TabIndex = 399
        '
        'rb562
        '
        Me.rb562.AutoSize = True
        Me.rb562.Location = New System.Drawing.Point(29, 3)
        Me.rb562.Name = "rb562"
        Me.rb562.Size = New System.Drawing.Size(14, 13)
        Me.rb562.TabIndex = 4
        Me.rb562.TabStop = True
        Me.rb562.UseVisualStyleBackColor = True
        '
        'rb561
        '
        Me.rb561.AutoSize = True
        Me.rb561.Location = New System.Drawing.Point(5, 3)
        Me.rb561.Name = "rb561"
        Me.rb561.Size = New System.Drawing.Size(14, 13)
        Me.rb561.TabIndex = 3
        Me.rb561.TabStop = True
        Me.rb561.UseVisualStyleBackColor = True
        '
        'Panel35
        '
        Me.Panel35.Controls.Add(Me.rb552)
        Me.Panel35.Controls.Add(Me.rb551)
        Me.Panel35.Location = New System.Drawing.Point(298, 1171)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(46, 19)
        Me.Panel35.TabIndex = 398
        '
        'rb552
        '
        Me.rb552.AutoSize = True
        Me.rb552.Location = New System.Drawing.Point(29, 3)
        Me.rb552.Name = "rb552"
        Me.rb552.Size = New System.Drawing.Size(14, 13)
        Me.rb552.TabIndex = 4
        Me.rb552.TabStop = True
        Me.rb552.UseVisualStyleBackColor = True
        '
        'rb551
        '
        Me.rb551.AutoSize = True
        Me.rb551.Location = New System.Drawing.Point(5, 3)
        Me.rb551.Name = "rb551"
        Me.rb551.Size = New System.Drawing.Size(14, 13)
        Me.rb551.TabIndex = 3
        Me.rb551.TabStop = True
        Me.rb551.UseVisualStyleBackColor = True
        '
        'Panel36
        '
        Me.Panel36.Controls.Add(Me.rb542)
        Me.Panel36.Controls.Add(Me.rb541)
        Me.Panel36.Location = New System.Drawing.Point(298, 1149)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(46, 19)
        Me.Panel36.TabIndex = 397
        '
        'rb542
        '
        Me.rb542.AutoSize = True
        Me.rb542.Location = New System.Drawing.Point(29, 3)
        Me.rb542.Name = "rb542"
        Me.rb542.Size = New System.Drawing.Size(14, 13)
        Me.rb542.TabIndex = 4
        Me.rb542.TabStop = True
        Me.rb542.UseVisualStyleBackColor = True
        '
        'rb541
        '
        Me.rb541.AutoSize = True
        Me.rb541.Location = New System.Drawing.Point(5, 3)
        Me.rb541.Name = "rb541"
        Me.rb541.Size = New System.Drawing.Size(14, 13)
        Me.rb541.TabIndex = 3
        Me.rb541.TabStop = True
        Me.rb541.UseVisualStyleBackColor = True
        '
        'Panel37
        '
        Me.Panel37.Controls.Add(Me.rb532)
        Me.Panel37.Controls.Add(Me.rb531)
        Me.Panel37.Location = New System.Drawing.Point(298, 1127)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(46, 19)
        Me.Panel37.TabIndex = 396
        '
        'rb532
        '
        Me.rb532.AutoSize = True
        Me.rb532.Location = New System.Drawing.Point(29, 3)
        Me.rb532.Name = "rb532"
        Me.rb532.Size = New System.Drawing.Size(14, 13)
        Me.rb532.TabIndex = 4
        Me.rb532.TabStop = True
        Me.rb532.UseVisualStyleBackColor = True
        '
        'rb531
        '
        Me.rb531.AutoSize = True
        Me.rb531.Location = New System.Drawing.Point(5, 3)
        Me.rb531.Name = "rb531"
        Me.rb531.Size = New System.Drawing.Size(14, 13)
        Me.rb531.TabIndex = 3
        Me.rb531.TabStop = True
        Me.rb531.UseVisualStyleBackColor = True
        '
        'Panel38
        '
        Me.Panel38.Controls.Add(Me.rb522)
        Me.Panel38.Controls.Add(Me.rb521)
        Me.Panel38.Location = New System.Drawing.Point(298, 1106)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(46, 19)
        Me.Panel38.TabIndex = 395
        '
        'rb522
        '
        Me.rb522.AutoSize = True
        Me.rb522.Location = New System.Drawing.Point(29, 3)
        Me.rb522.Name = "rb522"
        Me.rb522.Size = New System.Drawing.Size(14, 13)
        Me.rb522.TabIndex = 4
        Me.rb522.TabStop = True
        Me.rb522.UseVisualStyleBackColor = True
        '
        'rb521
        '
        Me.rb521.AutoSize = True
        Me.rb521.Location = New System.Drawing.Point(5, 3)
        Me.rb521.Name = "rb521"
        Me.rb521.Size = New System.Drawing.Size(14, 13)
        Me.rb521.TabIndex = 3
        Me.rb521.TabStop = True
        Me.rb521.UseVisualStyleBackColor = True
        '
        'Panel39
        '
        Me.Panel39.Controls.Add(Me.rb512)
        Me.Panel39.Controls.Add(Me.rb511)
        Me.Panel39.Location = New System.Drawing.Point(298, 1079)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(46, 19)
        Me.Panel39.TabIndex = 394
        '
        'rb512
        '
        Me.rb512.AutoSize = True
        Me.rb512.Location = New System.Drawing.Point(29, 3)
        Me.rb512.Name = "rb512"
        Me.rb512.Size = New System.Drawing.Size(14, 13)
        Me.rb512.TabIndex = 4
        Me.rb512.TabStop = True
        Me.rb512.UseVisualStyleBackColor = True
        '
        'rb511
        '
        Me.rb511.AutoSize = True
        Me.rb511.Location = New System.Drawing.Point(5, 3)
        Me.rb511.Name = "rb511"
        Me.rb511.Size = New System.Drawing.Size(14, 13)
        Me.rb511.TabIndex = 3
        Me.rb511.TabStop = True
        Me.rb511.UseVisualStyleBackColor = True
        '
        'Panel40
        '
        Me.Panel40.Controls.Add(Me.rb5112)
        Me.Panel40.Controls.Add(Me.rb5111)
        Me.Panel40.Location = New System.Drawing.Point(298, 1316)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(46, 19)
        Me.Panel40.TabIndex = 404
        '
        'rb5112
        '
        Me.rb5112.AutoSize = True
        Me.rb5112.Location = New System.Drawing.Point(29, 3)
        Me.rb5112.Name = "rb5112"
        Me.rb5112.Size = New System.Drawing.Size(14, 13)
        Me.rb5112.TabIndex = 4
        Me.rb5112.TabStop = True
        Me.rb5112.UseVisualStyleBackColor = True
        '
        'rb5111
        '
        Me.rb5111.AutoSize = True
        Me.rb5111.Location = New System.Drawing.Point(5, 3)
        Me.rb5111.Name = "rb5111"
        Me.rb5111.Size = New System.Drawing.Size(14, 13)
        Me.rb5111.TabIndex = 3
        Me.rb5111.TabStop = True
        Me.rb5111.UseVisualStyleBackColor = True
        '
        'Panel41
        '
        Me.Panel41.Controls.Add(Me.rb5102)
        Me.Panel41.Controls.Add(Me.rb5101)
        Me.Panel41.Location = New System.Drawing.Point(298, 1294)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(46, 19)
        Me.Panel41.TabIndex = 403
        '
        'rb5102
        '
        Me.rb5102.AutoSize = True
        Me.rb5102.Location = New System.Drawing.Point(29, 3)
        Me.rb5102.Name = "rb5102"
        Me.rb5102.Size = New System.Drawing.Size(14, 13)
        Me.rb5102.TabIndex = 4
        Me.rb5102.TabStop = True
        Me.rb5102.UseVisualStyleBackColor = True
        '
        'rb5101
        '
        Me.rb5101.AutoSize = True
        Me.rb5101.Location = New System.Drawing.Point(5, 3)
        Me.rb5101.Name = "rb5101"
        Me.rb5101.Size = New System.Drawing.Size(14, 13)
        Me.rb5101.TabIndex = 3
        Me.rb5101.TabStop = True
        Me.rb5101.UseVisualStyleBackColor = True
        '
        'Panel42
        '
        Me.Panel42.Controls.Add(Me.rb592)
        Me.Panel42.Controls.Add(Me.rb591)
        Me.Panel42.Location = New System.Drawing.Point(298, 1269)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(46, 19)
        Me.Panel42.TabIndex = 402
        '
        'rb592
        '
        Me.rb592.AutoSize = True
        Me.rb592.Location = New System.Drawing.Point(29, 3)
        Me.rb592.Name = "rb592"
        Me.rb592.Size = New System.Drawing.Size(14, 13)
        Me.rb592.TabIndex = 4
        Me.rb592.TabStop = True
        Me.rb592.UseVisualStyleBackColor = True
        '
        'rb591
        '
        Me.rb591.AutoSize = True
        Me.rb591.Location = New System.Drawing.Point(5, 3)
        Me.rb591.Name = "rb591"
        Me.rb591.Size = New System.Drawing.Size(14, 13)
        Me.rb591.TabIndex = 3
        Me.rb591.TabStop = True
        Me.rb591.UseVisualStyleBackColor = True
        '
        'Panel43
        '
        Me.Panel43.Controls.Add(Me.rb5142)
        Me.Panel43.Controls.Add(Me.rb5141)
        Me.Panel43.Location = New System.Drawing.Point(298, 1384)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(46, 19)
        Me.Panel43.TabIndex = 407
        '
        'rb5142
        '
        Me.rb5142.AutoSize = True
        Me.rb5142.Location = New System.Drawing.Point(29, 3)
        Me.rb5142.Name = "rb5142"
        Me.rb5142.Size = New System.Drawing.Size(14, 13)
        Me.rb5142.TabIndex = 4
        Me.rb5142.TabStop = True
        Me.rb5142.UseVisualStyleBackColor = True
        '
        'rb5141
        '
        Me.rb5141.AutoSize = True
        Me.rb5141.Location = New System.Drawing.Point(5, 3)
        Me.rb5141.Name = "rb5141"
        Me.rb5141.Size = New System.Drawing.Size(14, 13)
        Me.rb5141.TabIndex = 3
        Me.rb5141.TabStop = True
        Me.rb5141.UseVisualStyleBackColor = True
        '
        'Panel44
        '
        Me.Panel44.Controls.Add(Me.rb5132)
        Me.Panel44.Controls.Add(Me.rb5131)
        Me.Panel44.Location = New System.Drawing.Point(298, 1361)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(46, 19)
        Me.Panel44.TabIndex = 406
        '
        'rb5132
        '
        Me.rb5132.AutoSize = True
        Me.rb5132.Location = New System.Drawing.Point(29, 3)
        Me.rb5132.Name = "rb5132"
        Me.rb5132.Size = New System.Drawing.Size(14, 13)
        Me.rb5132.TabIndex = 4
        Me.rb5132.TabStop = True
        Me.rb5132.UseVisualStyleBackColor = True
        '
        'rb5131
        '
        Me.rb5131.AutoSize = True
        Me.rb5131.Location = New System.Drawing.Point(5, 3)
        Me.rb5131.Name = "rb5131"
        Me.rb5131.Size = New System.Drawing.Size(14, 13)
        Me.rb5131.TabIndex = 3
        Me.rb5131.TabStop = True
        Me.rb5131.UseVisualStyleBackColor = True
        '
        'Panel45
        '
        Me.Panel45.Controls.Add(Me.rb5122)
        Me.Panel45.Controls.Add(Me.rb5121)
        Me.Panel45.Location = New System.Drawing.Point(298, 1338)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(46, 19)
        Me.Panel45.TabIndex = 405
        '
        'rb5122
        '
        Me.rb5122.AutoSize = True
        Me.rb5122.Location = New System.Drawing.Point(29, 3)
        Me.rb5122.Name = "rb5122"
        Me.rb5122.Size = New System.Drawing.Size(14, 13)
        Me.rb5122.TabIndex = 4
        Me.rb5122.TabStop = True
        Me.rb5122.UseVisualStyleBackColor = True
        '
        'rb5121
        '
        Me.rb5121.AutoSize = True
        Me.rb5121.Location = New System.Drawing.Point(5, 3)
        Me.rb5121.Name = "rb5121"
        Me.rb5121.Size = New System.Drawing.Size(14, 13)
        Me.rb5121.TabIndex = 3
        Me.rb5121.TabStop = True
        Me.rb5121.UseVisualStyleBackColor = True
        '
        'Panel48
        '
        Me.Panel48.Controls.Add(Me.rb5152)
        Me.Panel48.Controls.Add(Me.rb5151)
        Me.Panel48.Location = New System.Drawing.Point(298, 1423)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(46, 19)
        Me.Panel48.TabIndex = 408
        '
        'rb5152
        '
        Me.rb5152.AutoSize = True
        Me.rb5152.Location = New System.Drawing.Point(29, 3)
        Me.rb5152.Name = "rb5152"
        Me.rb5152.Size = New System.Drawing.Size(14, 13)
        Me.rb5152.TabIndex = 4
        Me.rb5152.TabStop = True
        Me.rb5152.UseVisualStyleBackColor = True
        '
        'rb5151
        '
        Me.rb5151.AutoSize = True
        Me.rb5151.Location = New System.Drawing.Point(5, 3)
        Me.rb5151.Name = "rb5151"
        Me.rb5151.Size = New System.Drawing.Size(14, 13)
        Me.rb5151.TabIndex = 3
        Me.rb5151.TabStop = True
        Me.rb5151.UseVisualStyleBackColor = True
        '
        'Panel46
        '
        Me.Panel46.Controls.Add(Me.rb9102)
        Me.Panel46.Controls.Add(Me.rb9101)
        Me.Panel46.Location = New System.Drawing.Point(608, 1233)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(46, 19)
        Me.Panel46.TabIndex = 418
        '
        'rb9102
        '
        Me.rb9102.AutoSize = True
        Me.rb9102.Location = New System.Drawing.Point(29, 3)
        Me.rb9102.Name = "rb9102"
        Me.rb9102.Size = New System.Drawing.Size(14, 13)
        Me.rb9102.TabIndex = 4
        Me.rb9102.TabStop = True
        Me.rb9102.UseVisualStyleBackColor = True
        '
        'rb9101
        '
        Me.rb9101.AutoSize = True
        Me.rb9101.Location = New System.Drawing.Point(5, 3)
        Me.rb9101.Name = "rb9101"
        Me.rb9101.Size = New System.Drawing.Size(14, 13)
        Me.rb9101.TabIndex = 3
        Me.rb9101.TabStop = True
        Me.rb9101.UseVisualStyleBackColor = True
        '
        'Panel47
        '
        Me.Panel47.Controls.Add(Me.rb992)
        Me.Panel47.Controls.Add(Me.rb991)
        Me.Panel47.Location = New System.Drawing.Point(608, 1198)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(46, 19)
        Me.Panel47.TabIndex = 417
        '
        'rb992
        '
        Me.rb992.AutoSize = True
        Me.rb992.Location = New System.Drawing.Point(29, 3)
        Me.rb992.Name = "rb992"
        Me.rb992.Size = New System.Drawing.Size(14, 13)
        Me.rb992.TabIndex = 4
        Me.rb992.TabStop = True
        Me.rb992.UseVisualStyleBackColor = True
        '
        'rb991
        '
        Me.rb991.AutoSize = True
        Me.rb991.Location = New System.Drawing.Point(5, 3)
        Me.rb991.Name = "rb991"
        Me.rb991.Size = New System.Drawing.Size(14, 13)
        Me.rb991.TabIndex = 3
        Me.rb991.TabStop = True
        Me.rb991.UseVisualStyleBackColor = True
        '
        'Panel49
        '
        Me.Panel49.Controls.Add(Me.rb982)
        Me.Panel49.Controls.Add(Me.rb981)
        Me.Panel49.Location = New System.Drawing.Point(608, 1151)
        Me.Panel49.Name = "Panel49"
        Me.Panel49.Size = New System.Drawing.Size(46, 19)
        Me.Panel49.TabIndex = 416
        '
        'rb982
        '
        Me.rb982.AutoSize = True
        Me.rb982.Location = New System.Drawing.Point(29, 3)
        Me.rb982.Name = "rb982"
        Me.rb982.Size = New System.Drawing.Size(14, 13)
        Me.rb982.TabIndex = 4
        Me.rb982.TabStop = True
        Me.rb982.UseVisualStyleBackColor = True
        '
        'rb981
        '
        Me.rb981.AutoSize = True
        Me.rb981.Location = New System.Drawing.Point(5, 3)
        Me.rb981.Name = "rb981"
        Me.rb981.Size = New System.Drawing.Size(14, 13)
        Me.rb981.TabIndex = 3
        Me.rb981.TabStop = True
        Me.rb981.UseVisualStyleBackColor = True
        '
        'Panel50
        '
        Me.Panel50.Controls.Add(Me.rb972)
        Me.Panel50.Controls.Add(Me.rb971)
        Me.Panel50.Location = New System.Drawing.Point(608, 1108)
        Me.Panel50.Name = "Panel50"
        Me.Panel50.Size = New System.Drawing.Size(46, 19)
        Me.Panel50.TabIndex = 415
        '
        'rb972
        '
        Me.rb972.AutoSize = True
        Me.rb972.Location = New System.Drawing.Point(29, 3)
        Me.rb972.Name = "rb972"
        Me.rb972.Size = New System.Drawing.Size(14, 13)
        Me.rb972.TabIndex = 4
        Me.rb972.TabStop = True
        Me.rb972.UseVisualStyleBackColor = True
        '
        'rb971
        '
        Me.rb971.AutoSize = True
        Me.rb971.Location = New System.Drawing.Point(5, 3)
        Me.rb971.Name = "rb971"
        Me.rb971.Size = New System.Drawing.Size(14, 13)
        Me.rb971.TabIndex = 3
        Me.rb971.TabStop = True
        Me.rb971.UseVisualStyleBackColor = True
        '
        'Panel51
        '
        Me.Panel51.Controls.Add(Me.rb962)
        Me.Panel51.Controls.Add(Me.rb961)
        Me.Panel51.Location = New System.Drawing.Point(608, 1085)
        Me.Panel51.Name = "Panel51"
        Me.Panel51.Size = New System.Drawing.Size(46, 19)
        Me.Panel51.TabIndex = 414
        '
        'rb962
        '
        Me.rb962.AutoSize = True
        Me.rb962.Location = New System.Drawing.Point(29, 3)
        Me.rb962.Name = "rb962"
        Me.rb962.Size = New System.Drawing.Size(14, 13)
        Me.rb962.TabIndex = 4
        Me.rb962.TabStop = True
        Me.rb962.UseVisualStyleBackColor = True
        '
        'rb961
        '
        Me.rb961.AutoSize = True
        Me.rb961.Location = New System.Drawing.Point(5, 3)
        Me.rb961.Name = "rb961"
        Me.rb961.Size = New System.Drawing.Size(14, 13)
        Me.rb961.TabIndex = 3
        Me.rb961.TabStop = True
        Me.rb961.UseVisualStyleBackColor = True
        '
        'Panel52
        '
        Me.Panel52.Controls.Add(Me.rb952)
        Me.Panel52.Controls.Add(Me.rb951)
        Me.Panel52.Location = New System.Drawing.Point(608, 1050)
        Me.Panel52.Name = "Panel52"
        Me.Panel52.Size = New System.Drawing.Size(46, 19)
        Me.Panel52.TabIndex = 413
        '
        'rb952
        '
        Me.rb952.AutoSize = True
        Me.rb952.Location = New System.Drawing.Point(29, 3)
        Me.rb952.Name = "rb952"
        Me.rb952.Size = New System.Drawing.Size(14, 13)
        Me.rb952.TabIndex = 4
        Me.rb952.TabStop = True
        Me.rb952.UseVisualStyleBackColor = True
        '
        'rb951
        '
        Me.rb951.AutoSize = True
        Me.rb951.Location = New System.Drawing.Point(5, 3)
        Me.rb951.Name = "rb951"
        Me.rb951.Size = New System.Drawing.Size(14, 13)
        Me.rb951.TabIndex = 3
        Me.rb951.TabStop = True
        Me.rb951.UseVisualStyleBackColor = True
        '
        'Panel53
        '
        Me.Panel53.Controls.Add(Me.rb942)
        Me.Panel53.Controls.Add(Me.rb941)
        Me.Panel53.Location = New System.Drawing.Point(608, 1015)
        Me.Panel53.Name = "Panel53"
        Me.Panel53.Size = New System.Drawing.Size(46, 19)
        Me.Panel53.TabIndex = 412
        '
        'rb942
        '
        Me.rb942.AutoSize = True
        Me.rb942.Location = New System.Drawing.Point(29, 3)
        Me.rb942.Name = "rb942"
        Me.rb942.Size = New System.Drawing.Size(14, 13)
        Me.rb942.TabIndex = 4
        Me.rb942.TabStop = True
        Me.rb942.UseVisualStyleBackColor = True
        '
        'rb941
        '
        Me.rb941.AutoSize = True
        Me.rb941.Location = New System.Drawing.Point(5, 3)
        Me.rb941.Name = "rb941"
        Me.rb941.Size = New System.Drawing.Size(14, 13)
        Me.rb941.TabIndex = 3
        Me.rb941.TabStop = True
        Me.rb941.UseVisualStyleBackColor = True
        '
        'Panel54
        '
        Me.Panel54.Controls.Add(Me.rb932)
        Me.Panel54.Controls.Add(Me.rb931)
        Me.Panel54.Location = New System.Drawing.Point(608, 977)
        Me.Panel54.Name = "Panel54"
        Me.Panel54.Size = New System.Drawing.Size(46, 19)
        Me.Panel54.TabIndex = 411
        '
        'rb932
        '
        Me.rb932.AutoSize = True
        Me.rb932.Location = New System.Drawing.Point(29, 3)
        Me.rb932.Name = "rb932"
        Me.rb932.Size = New System.Drawing.Size(14, 13)
        Me.rb932.TabIndex = 4
        Me.rb932.TabStop = True
        Me.rb932.UseVisualStyleBackColor = True
        '
        'rb931
        '
        Me.rb931.AutoSize = True
        Me.rb931.Location = New System.Drawing.Point(5, 3)
        Me.rb931.Name = "rb931"
        Me.rb931.Size = New System.Drawing.Size(14, 13)
        Me.rb931.TabIndex = 3
        Me.rb931.TabStop = True
        Me.rb931.UseVisualStyleBackColor = True
        '
        'Panel55
        '
        Me.Panel55.Controls.Add(Me.rb922)
        Me.Panel55.Controls.Add(Me.rb921)
        Me.Panel55.Location = New System.Drawing.Point(608, 944)
        Me.Panel55.Name = "Panel55"
        Me.Panel55.Size = New System.Drawing.Size(46, 19)
        Me.Panel55.TabIndex = 410
        '
        'rb922
        '
        Me.rb922.AutoSize = True
        Me.rb922.Location = New System.Drawing.Point(29, 3)
        Me.rb922.Name = "rb922"
        Me.rb922.Size = New System.Drawing.Size(14, 13)
        Me.rb922.TabIndex = 4
        Me.rb922.TabStop = True
        Me.rb922.UseVisualStyleBackColor = True
        '
        'rb921
        '
        Me.rb921.AutoSize = True
        Me.rb921.Location = New System.Drawing.Point(5, 3)
        Me.rb921.Name = "rb921"
        Me.rb921.Size = New System.Drawing.Size(14, 13)
        Me.rb921.TabIndex = 3
        Me.rb921.TabStop = True
        Me.rb921.UseVisualStyleBackColor = True
        '
        'Panel56
        '
        Me.Panel56.Controls.Add(Me.rb912)
        Me.Panel56.Controls.Add(Me.rb911)
        Me.Panel56.Location = New System.Drawing.Point(608, 905)
        Me.Panel56.Name = "Panel56"
        Me.Panel56.Size = New System.Drawing.Size(46, 19)
        Me.Panel56.TabIndex = 409
        '
        'rb912
        '
        Me.rb912.AutoSize = True
        Me.rb912.Location = New System.Drawing.Point(29, 3)
        Me.rb912.Name = "rb912"
        Me.rb912.Size = New System.Drawing.Size(14, 13)
        Me.rb912.TabIndex = 4
        Me.rb912.TabStop = True
        Me.rb912.UseVisualStyleBackColor = True
        '
        'rb911
        '
        Me.rb911.AutoSize = True
        Me.rb911.Location = New System.Drawing.Point(5, 3)
        Me.rb911.Name = "rb911"
        Me.rb911.Size = New System.Drawing.Size(14, 13)
        Me.rb911.TabIndex = 3
        Me.rb911.TabStop = True
        Me.rb911.UseVisualStyleBackColor = True
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Location = New System.Drawing.Point(111, 266)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(506, 13)
        Me.Label127.TabIndex = 419
        Me.Label127.Text = "Tillater du at blodbanken sender deg epost(Innkalling, timepåminning, eventuelt a" &
    "nnen viktig informasjon)?"
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(111, 288)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(503, 13)
        Me.Label125.TabIndex = 420
        Me.Label125.Text = "Tillater du at blodbanken sender deg SMS(Innkalling, timepåminning, eventuelt ann" &
    "en viktig informasjon)?"
        '
        'Panel57
        '
        Me.Panel57.Controls.Add(Me.rbEpostNei)
        Me.Panel57.Controls.Add(Me.rbEpostJa)
        Me.Panel57.Location = New System.Drawing.Point(62, 263)
        Me.Panel57.Name = "Panel57"
        Me.Panel57.Size = New System.Drawing.Size(46, 19)
        Me.Panel57.TabIndex = 421
        '
        'rbEpostNei
        '
        Me.rbEpostNei.AutoSize = True
        Me.rbEpostNei.Location = New System.Drawing.Point(29, 3)
        Me.rbEpostNei.Name = "rbEpostNei"
        Me.rbEpostNei.Size = New System.Drawing.Size(14, 13)
        Me.rbEpostNei.TabIndex = 4
        Me.rbEpostNei.TabStop = True
        Me.rbEpostNei.UseVisualStyleBackColor = True
        '
        'rbEpostJa
        '
        Me.rbEpostJa.AutoSize = True
        Me.rbEpostJa.Location = New System.Drawing.Point(5, 3)
        Me.rbEpostJa.Name = "rbEpostJa"
        Me.rbEpostJa.Size = New System.Drawing.Size(14, 13)
        Me.rbEpostJa.TabIndex = 3
        Me.rbEpostJa.TabStop = True
        Me.rbEpostJa.UseVisualStyleBackColor = True
        '
        'Panel58
        '
        Me.Panel58.Controls.Add(Me.rbSMSNei)
        Me.Panel58.Controls.Add(Me.rbSMSJa)
        Me.Panel58.Location = New System.Drawing.Point(62, 285)
        Me.Panel58.Name = "Panel58"
        Me.Panel58.Size = New System.Drawing.Size(46, 19)
        Me.Panel58.TabIndex = 375
        '
        'rbSMSNei
        '
        Me.rbSMSNei.AutoSize = True
        Me.rbSMSNei.Location = New System.Drawing.Point(29, 3)
        Me.rbSMSNei.Name = "rbSMSNei"
        Me.rbSMSNei.Size = New System.Drawing.Size(14, 13)
        Me.rbSMSNei.TabIndex = 4
        Me.rbSMSNei.TabStop = True
        Me.rbSMSNei.UseVisualStyleBackColor = True
        '
        'rbSMSJa
        '
        Me.rbSMSJa.AutoSize = True
        Me.rbSMSJa.Location = New System.Drawing.Point(5, 3)
        Me.rbSMSJa.Name = "rbSMSJa"
        Me.rbSMSJa.Size = New System.Drawing.Size(14, 13)
        Me.rbSMSJa.TabIndex = 3
        Me.rbSMSJa.TabStop = True
        Me.rbSMSJa.UseVisualStyleBackColor = True
        '
        'Panel59
        '
        Me.Panel59.Controls.Add(Me.rb1102)
        Me.Panel59.Controls.Add(Me.rb3101)
        Me.Panel59.Location = New System.Drawing.Point(298, 946)
        Me.Panel59.Name = "Panel59"
        Me.Panel59.Size = New System.Drawing.Size(46, 19)
        Me.Panel59.TabIndex = 424
        '
        'rb1102
        '
        Me.rb1102.AutoSize = True
        Me.rb1102.Location = New System.Drawing.Point(29, 3)
        Me.rb1102.Name = "rb1102"
        Me.rb1102.Size = New System.Drawing.Size(14, 13)
        Me.rb1102.TabIndex = 4
        Me.rb1102.TabStop = True
        Me.rb1102.UseVisualStyleBackColor = True
        '
        'rb3101
        '
        Me.rb3101.AutoSize = True
        Me.rb3101.Location = New System.Drawing.Point(5, 3)
        Me.rb3101.Name = "rb3101"
        Me.rb3101.Size = New System.Drawing.Size(14, 13)
        Me.rb3101.TabIndex = 3
        Me.rb3101.TabStop = True
        Me.rb3101.UseVisualStyleBackColor = True
        '
        'Panel60
        '
        Me.Panel60.Controls.Add(Me.rb392)
        Me.Panel60.Controls.Add(Me.rb391)
        Me.Panel60.Location = New System.Drawing.Point(298, 924)
        Me.Panel60.Name = "Panel60"
        Me.Panel60.Size = New System.Drawing.Size(46, 19)
        Me.Panel60.TabIndex = 389
        '
        'rb392
        '
        Me.rb392.AutoSize = True
        Me.rb392.Location = New System.Drawing.Point(29, 3)
        Me.rb392.Name = "rb392"
        Me.rb392.Size = New System.Drawing.Size(14, 13)
        Me.rb392.TabIndex = 4
        Me.rb392.TabStop = True
        Me.rb392.UseVisualStyleBackColor = True
        '
        'rb391
        '
        Me.rb391.AutoSize = True
        Me.rb391.Location = New System.Drawing.Point(5, 3)
        Me.rb391.Name = "rb391"
        Me.rb391.Size = New System.Drawing.Size(14, 13)
        Me.rb391.TabIndex = 3
        Me.rb391.TabStop = True
        Me.rb391.UseVisualStyleBackColor = True
        '
        'btnInfo
        '
        Me.btnInfo.Location = New System.Drawing.Point(256, 161)
        Me.btnInfo.Name = "btnInfo"
        Me.btnInfo.Size = New System.Drawing.Size(224, 55)
        Me.btnInfo.TabIndex = 426
        Me.btnInfo.Text = "Litt viktig informasjon"
        Me.btnInfo.UseVisualStyleBackColor = True
        '
        'lblDato
        '
        Me.lblDato.AutoSize = True
        Me.lblDato.Location = New System.Drawing.Point(55, 1559)
        Me.lblDato.Name = "lblDato"
        Me.lblDato.Size = New System.Drawing.Size(30, 13)
        Me.lblDato.TabIndex = 428
        Me.lblDato.Text = "Dato"
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Location = New System.Drawing.Point(55, 442)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(205, 13)
        Me.Label129.TabIndex = 429
        Me.Label129.Text = "Har du åpne sår, eksem eller hudsykdom?"
        '
        'Panel61
        '
        Me.Panel61.Controls.Add(Me.rb152)
        Me.Panel61.Controls.Add(Me.rb151)
        Me.Panel61.Location = New System.Drawing.Point(298, 440)
        Me.Panel61.Name = "Panel61"
        Me.Panel61.Size = New System.Drawing.Size(46, 19)
        Me.Panel61.TabIndex = 430
        '
        'rb152
        '
        Me.rb152.AutoSize = True
        Me.rb152.Location = New System.Drawing.Point(29, 3)
        Me.rb152.Name = "rb152"
        Me.rb152.Size = New System.Drawing.Size(14, 13)
        Me.rb152.TabIndex = 4
        Me.rb152.TabStop = True
        Me.rb152.UseVisualStyleBackColor = True
        '
        'rb151
        '
        Me.rb151.AutoSize = True
        Me.rb151.Location = New System.Drawing.Point(5, 3)
        Me.rb151.Name = "rb151"
        Me.rb151.Size = New System.Drawing.Size(14, 13)
        Me.rb151.TabIndex = 3
        Me.rb151.TabStop = True
        Me.rb151.UseVisualStyleBackColor = True
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Location = New System.Drawing.Point(55, 468)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(136, 13)
        Me.Label130.TabIndex = 431
        Me.Label130.Text = "Har du piercing i slimhinne?"
        '
        'Panel62
        '
        Me.Panel62.Controls.Add(Me.rb162)
        Me.Panel62.Controls.Add(Me.rb161)
        Me.Panel62.Location = New System.Drawing.Point(298, 465)
        Me.Panel62.Name = "Panel62"
        Me.Panel62.Size = New System.Drawing.Size(46, 19)
        Me.Panel62.TabIndex = 432
        '
        'rb162
        '
        Me.rb162.AutoSize = True
        Me.rb162.Location = New System.Drawing.Point(29, 3)
        Me.rb162.Name = "rb162"
        Me.rb162.Size = New System.Drawing.Size(14, 13)
        Me.rb162.TabIndex = 4
        Me.rb162.TabStop = True
        Me.rb162.UseVisualStyleBackColor = True
        '
        'rb161
        '
        Me.rb161.AutoSize = True
        Me.rb161.Location = New System.Drawing.Point(5, 3)
        Me.rb161.Name = "rb161"
        Me.rb161.Size = New System.Drawing.Size(14, 13)
        Me.rb161.TabIndex = 3
        Me.rb161.TabStop = True
        Me.rb161.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(341, 1633)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 13)
        Me.Label3.TabIndex = 433
        '
        'chkSjekk
        '
        Me.chkSjekk.AutoSize = True
        Me.chkSjekk.Location = New System.Drawing.Point(256, 228)
        Me.chkSjekk.Name = "chkSjekk"
        Me.chkSjekk.Size = New System.Drawing.Size(201, 17)
        Me.chkSjekk.TabIndex = 434
        Me.chkSjekk.Text = "Jeg har lest og forstått informasjonen."
        Me.chkSjekk.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(55, 52)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 435
        Me.Label4.Text = "Fornavn:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(55, 75)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 436
        Me.Label5.Text = "Etternavn:"
        '
        'lblFornavn
        '
        Me.lblFornavn.AutoSize = True
        Me.lblFornavn.Location = New System.Drawing.Point(144, 52)
        Me.lblFornavn.Name = "lblFornavn"
        Me.lblFornavn.Size = New System.Drawing.Size(0, 13)
        Me.lblFornavn.TabIndex = 437
        '
        'lblEtternavn
        '
        Me.lblEtternavn.AutoSize = True
        Me.lblEtternavn.Location = New System.Drawing.Point(144, 75)
        Me.lblEtternavn.Name = "lblEtternavn"
        Me.lblEtternavn.Size = New System.Drawing.Size(0, 13)
        Me.lblEtternavn.TabIndex = 438
        '
        'label4030
        '
        Me.label4030.AutoSize = True
        Me.label4030.Location = New System.Drawing.Point(55, 101)
        Me.label4030.Name = "label4030"
        Me.label4030.Size = New System.Drawing.Size(78, 13)
        Me.label4030.TabIndex = 439
        Me.label4030.Text = "Brukernummer:"
        '
        'lblPersonID
        '
        Me.lblPersonID.AutoSize = True
        Me.lblPersonID.Location = New System.Drawing.Point(139, 101)
        Me.lblPersonID.Name = "lblPersonID"
        Me.lblPersonID.Size = New System.Drawing.Size(0, 13)
        Me.lblPersonID.TabIndex = 440
        '
        'egenerklering
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(722, 463)
        Me.Controls.Add(Me.lblPersonID)
        Me.Controls.Add(Me.label4030)
        Me.Controls.Add(Me.lblEtternavn)
        Me.Controls.Add(Me.lblFornavn)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.chkSjekk)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel62)
        Me.Controls.Add(Me.Label130)
        Me.Controls.Add(Me.Panel61)
        Me.Controls.Add(Me.Label129)
        Me.Controls.Add(Me.lblDato)
        Me.Controls.Add(Me.btnInfo)
        Me.Controls.Add(Me.Panel60)
        Me.Controls.Add(Me.Panel59)
        Me.Controls.Add(Me.Panel58)
        Me.Controls.Add(Me.Panel57)
        Me.Controls.Add(Me.Label125)
        Me.Controls.Add(Me.Label127)
        Me.Controls.Add(Me.Panel46)
        Me.Controls.Add(Me.Panel47)
        Me.Controls.Add(Me.Panel49)
        Me.Controls.Add(Me.Panel50)
        Me.Controls.Add(Me.Panel51)
        Me.Controls.Add(Me.Panel52)
        Me.Controls.Add(Me.Panel53)
        Me.Controls.Add(Me.Panel54)
        Me.Controls.Add(Me.Panel55)
        Me.Controls.Add(Me.Panel56)
        Me.Controls.Add(Me.Panel48)
        Me.Controls.Add(Me.Panel43)
        Me.Controls.Add(Me.Panel44)
        Me.Controls.Add(Me.Panel45)
        Me.Controls.Add(Me.Panel40)
        Me.Controls.Add(Me.Panel41)
        Me.Controls.Add(Me.Panel42)
        Me.Controls.Add(Me.Panel32)
        Me.Controls.Add(Me.Panel33)
        Me.Controls.Add(Me.Panel34)
        Me.Controls.Add(Me.Panel35)
        Me.Controls.Add(Me.Panel36)
        Me.Controls.Add(Me.Panel37)
        Me.Controls.Add(Me.Panel38)
        Me.Controls.Add(Me.Panel39)
        Me.Controls.Add(Me.Panel31)
        Me.Controls.Add(Me.Panel26)
        Me.Controls.Add(Me.Panel27)
        Me.Controls.Add(Me.Panel28)
        Me.Controls.Add(Me.Panel29)
        Me.Controls.Add(Me.Panel30)
        Me.Controls.Add(Me.Panel25)
        Me.Controls.Add(Me.Panel24)
        Me.Controls.Add(Me.Panel21)
        Me.Controls.Add(Me.Panel22)
        Me.Controls.Add(Me.Panel23)
        Me.Controls.Add(Me.Panel18)
        Me.Controls.Add(Me.Panel19)
        Me.Controls.Add(Me.Panel20)
        Me.Controls.Add(Me.Panel16)
        Me.Controls.Add(Me.Panel17)
        Me.Controls.Add(Me.Panel12)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Panel9)
        Me.Controls.Add(Me.Panel14)
        Me.Controls.Add(Me.Panel15)
        Me.Controls.Add(Me.Panel10)
        Me.Controls.Add(Me.Panel11)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnSendInn)
        Me.Controls.Add(Me.Label123)
        Me.Controls.Add(Me.Label124)
        Me.Controls.Add(Me.Label121)
        Me.Controls.Add(Me.Label122)
        Me.Controls.Add(Me.Label120)
        Me.Controls.Add(Me.Label119)
        Me.Controls.Add(Me.Label118)
        Me.Controls.Add(Me.Label117)
        Me.Controls.Add(Me.Label116)
        Me.Controls.Add(Me.Label115)
        Me.Controls.Add(Me.Label114)
        Me.Controls.Add(Me.Label113)
        Me.Controls.Add(Me.Label112)
        Me.Controls.Add(Me.Label111)
        Me.Controls.Add(Me.Label110)
        Me.Controls.Add(Me.Label109)
        Me.Controls.Add(Me.Label108)
        Me.Controls.Add(Me.Label106)
        Me.Controls.Add(Me.Label107)
        Me.Controls.Add(Me.Label104)
        Me.Controls.Add(Me.Label105)
        Me.Controls.Add(Me.Label103)
        Me.Controls.Add(Me.Label101)
        Me.Controls.Add(Me.Label102)
        Me.Controls.Add(Me.Label99)
        Me.Controls.Add(Me.Label100)
        Me.Controls.Add(Me.Label98)
        Me.Controls.Add(Me.Label97)
        Me.Controls.Add(Me.Label79)
        Me.Controls.Add(Me.Label80)
        Me.Controls.Add(Me.Label81)
        Me.Controls.Add(Me.Label82)
        Me.Controls.Add(Me.Label83)
        Me.Controls.Add(Me.Label84)
        Me.Controls.Add(Me.Label85)
        Me.Controls.Add(Me.Label86)
        Me.Controls.Add(Me.Label87)
        Me.Controls.Add(Me.Label88)
        Me.Controls.Add(Me.Label89)
        Me.Controls.Add(Me.Label90)
        Me.Controls.Add(Me.Label91)
        Me.Controls.Add(Me.Label92)
        Me.Controls.Add(Me.Label93)
        Me.Controls.Add(Me.Label94)
        Me.Controls.Add(Me.Label95)
        Me.Controls.Add(Me.Label96)
        Me.Controls.Add(Me.Label78)
        Me.Controls.Add(Me.Label77)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label67)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.Label63)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "egenerklering"
        Me.Text = "egenerklering"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout()
        Me.Panel34.ResumeLayout(False)
        Me.Panel34.PerformLayout()
        Me.Panel35.ResumeLayout(False)
        Me.Panel35.PerformLayout()
        Me.Panel36.ResumeLayout(False)
        Me.Panel36.PerformLayout()
        Me.Panel37.ResumeLayout(False)
        Me.Panel37.PerformLayout()
        Me.Panel38.ResumeLayout(False)
        Me.Panel38.PerformLayout()
        Me.Panel39.ResumeLayout(False)
        Me.Panel39.PerformLayout()
        Me.Panel40.ResumeLayout(False)
        Me.Panel40.PerformLayout()
        Me.Panel41.ResumeLayout(False)
        Me.Panel41.PerformLayout()
        Me.Panel42.ResumeLayout(False)
        Me.Panel42.PerformLayout()
        Me.Panel43.ResumeLayout(False)
        Me.Panel43.PerformLayout()
        Me.Panel44.ResumeLayout(False)
        Me.Panel44.PerformLayout()
        Me.Panel45.ResumeLayout(False)
        Me.Panel45.PerformLayout()
        Me.Panel48.ResumeLayout(False)
        Me.Panel48.PerformLayout()
        Me.Panel46.ResumeLayout(False)
        Me.Panel46.PerformLayout()
        Me.Panel47.ResumeLayout(False)
        Me.Panel47.PerformLayout()
        Me.Panel49.ResumeLayout(False)
        Me.Panel49.PerformLayout()
        Me.Panel50.ResumeLayout(False)
        Me.Panel50.PerformLayout()
        Me.Panel51.ResumeLayout(False)
        Me.Panel51.PerformLayout()
        Me.Panel52.ResumeLayout(False)
        Me.Panel52.PerformLayout()
        Me.Panel53.ResumeLayout(False)
        Me.Panel53.PerformLayout()
        Me.Panel54.ResumeLayout(False)
        Me.Panel54.PerformLayout()
        Me.Panel55.ResumeLayout(False)
        Me.Panel55.PerformLayout()
        Me.Panel56.ResumeLayout(False)
        Me.Panel56.PerformLayout()
        Me.Panel57.ResumeLayout(False)
        Me.Panel57.PerformLayout()
        Me.Panel58.ResumeLayout(False)
        Me.Panel58.PerformLayout()
        Me.Panel59.ResumeLayout(False)
        Me.Panel59.PerformLayout()
        Me.Panel60.ResumeLayout(False)
        Me.Panel60.PerformLayout()
        Me.Panel61.ResumeLayout(False)
        Me.Panel61.PerformLayout()
        Me.Panel62.ResumeLayout(False)
        Me.Panel62.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label87 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents Label89 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label91 As Label
    Friend WithEvents Label92 As Label
    Friend WithEvents Label93 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label109 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents Label112 As Label
    Friend WithEvents Label113 As Label
    Friend WithEvents Label114 As Label
    Friend WithEvents Label115 As Label
    Friend WithEvents Label116 As Label
    Friend WithEvents Label117 As Label
    Friend WithEvents Label118 As Label
    Friend WithEvents Label119 As Label
    Friend WithEvents Label120 As Label
    Friend WithEvents Label121 As Label
    Friend WithEvents Label122 As Label
    Friend WithEvents Label123 As Label
    Friend WithEvents Label124 As Label
    Friend WithEvents btnSendInn As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents rb612 As RadioButton
    Friend WithEvents rb611 As RadioButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents rb622 As RadioButton
    Friend WithEvents rb621 As RadioButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents rb642 As RadioButton
    Friend WithEvents rb641 As RadioButton
    Friend WithEvents Panel4 As Panel
    Friend WithEvents rb652 As RadioButton
    Friend WithEvents rb651 As RadioButton
    Friend WithEvents Panel5 As Panel
    Friend WithEvents rb662 As RadioButton
    Friend WithEvents rb661 As RadioButton
    Friend WithEvents Panel6 As Panel
    Friend WithEvents rb672 As RadioButton
    Friend WithEvents rb671 As RadioButton
    Friend WithEvents Panel7 As Panel
    Friend WithEvents rb632 As RadioButton
    Friend WithEvents rb631 As RadioButton
    Friend WithEvents Panel8 As Panel
    Friend WithEvents rb132 As RadioButton
    Friend WithEvents rb131 As RadioButton
    Friend WithEvents Panel9 As Panel
    Friend WithEvents rb142 As RadioButton
    Friend WithEvents rb141 As RadioButton
    Friend WithEvents Panel10 As Panel
    Friend WithEvents rb122 As RadioButton
    Friend WithEvents rb121 As RadioButton
    Friend WithEvents Panel11 As Panel
    Friend WithEvents rb112 As RadioButton
    Friend WithEvents rb111 As RadioButton
    Friend WithEvents Panel12 As Panel
    Friend WithEvents rb232 As RadioButton
    Friend WithEvents rb231 As RadioButton
    Friend WithEvents Panel14 As Panel
    Friend WithEvents rb222 As RadioButton
    Friend WithEvents rb221 As RadioButton
    Friend WithEvents Panel15 As Panel
    Friend WithEvents rb212 As RadioButton
    Friend WithEvents rb211 As RadioButton
    Friend WithEvents Panel16 As Panel
    Friend WithEvents rb252 As RadioButton
    Friend WithEvents rb251 As RadioButton
    Friend WithEvents Panel17 As Panel
    Friend WithEvents rb242 As RadioButton
    Friend WithEvents rb241 As RadioButton
    Friend WithEvents Panel18 As Panel
    Friend WithEvents rb332 As RadioButton
    Friend WithEvents rb331 As RadioButton
    Friend WithEvents Panel19 As Panel
    Friend WithEvents rb322 As RadioButton
    Friend WithEvents rb321 As RadioButton
    Friend WithEvents Panel20 As Panel
    Friend WithEvents rb312 As RadioButton
    Friend WithEvents rb311 As RadioButton
    Friend WithEvents Panel21 As Panel
    Friend WithEvents rb362 As RadioButton
    Friend WithEvents rb361 As RadioButton
    Friend WithEvents Panel22 As Panel
    Friend WithEvents rb352 As RadioButton
    Friend WithEvents rb351 As RadioButton
    Friend WithEvents Panel23 As Panel
    Friend WithEvents rb342 As RadioButton
    Friend WithEvents rb341 As RadioButton
    Friend WithEvents Panel24 As Panel
    Friend WithEvents rb372 As RadioButton
    Friend WithEvents rb371 As RadioButton
    Friend WithEvents Panel25 As Panel
    Friend WithEvents rb382 As RadioButton
    Friend WithEvents rb381 As RadioButton
    Friend WithEvents Panel27 As Panel
    Friend WithEvents rb742 As RadioButton
    Friend WithEvents rb741 As RadioButton
    Friend WithEvents Panel28 As Panel
    Friend WithEvents rb732 As RadioButton
    Friend WithEvents rb731 As RadioButton
    Friend WithEvents Panel29 As Panel
    Friend WithEvents rb722 As RadioButton
    Friend WithEvents rb721 As RadioButton
    Friend WithEvents Panel30 As Panel
    Friend WithEvents rb712 As RadioButton
    Friend WithEvents rb711 As RadioButton
    Friend WithEvents Panel26 As Panel
    Friend WithEvents rb412 As RadioButton
    Friend WithEvents rb411 As RadioButton
    Friend WithEvents Panel31 As Panel
    Friend WithEvents rb812 As RadioButton
    Friend WithEvents rb811 As RadioButton
    Friend WithEvents Panel32 As Panel
    Friend WithEvents rb582 As RadioButton
    Friend WithEvents rb581 As RadioButton
    Friend WithEvents Panel33 As Panel
    Friend WithEvents rb572 As RadioButton
    Friend WithEvents rb571 As RadioButton
    Friend WithEvents Panel34 As Panel
    Friend WithEvents rb562 As RadioButton
    Friend WithEvents rb561 As RadioButton
    Friend WithEvents Panel35 As Panel
    Friend WithEvents rb552 As RadioButton
    Friend WithEvents rb551 As RadioButton
    Friend WithEvents Panel36 As Panel
    Friend WithEvents rb542 As RadioButton
    Friend WithEvents rb541 As RadioButton
    Friend WithEvents Panel37 As Panel
    Friend WithEvents rb532 As RadioButton
    Friend WithEvents rb531 As RadioButton
    Friend WithEvents Panel38 As Panel
    Friend WithEvents rb522 As RadioButton
    Friend WithEvents rb521 As RadioButton
    Friend WithEvents Panel39 As Panel
    Friend WithEvents rb512 As RadioButton
    Friend WithEvents rb511 As RadioButton
    Friend WithEvents Panel40 As Panel
    Friend WithEvents rb5112 As RadioButton
    Friend WithEvents rb5111 As RadioButton
    Friend WithEvents Panel41 As Panel
    Friend WithEvents rb5102 As RadioButton
    Friend WithEvents rb5101 As RadioButton
    Friend WithEvents Panel42 As Panel
    Friend WithEvents rb592 As RadioButton
    Friend WithEvents rb591 As RadioButton
    Friend WithEvents Panel43 As Panel
    Friend WithEvents rb5142 As RadioButton
    Friend WithEvents rb5141 As RadioButton
    Friend WithEvents Panel44 As Panel
    Friend WithEvents rb5132 As RadioButton
    Friend WithEvents rb5131 As RadioButton
    Friend WithEvents Panel45 As Panel
    Friend WithEvents rb5122 As RadioButton
    Friend WithEvents rb5121 As RadioButton
    Friend WithEvents Panel48 As Panel
    Friend WithEvents rb5152 As RadioButton
    Friend WithEvents rb5151 As RadioButton
    Friend WithEvents Panel46 As Panel
    Friend WithEvents rb9102 As RadioButton
    Friend WithEvents rb9101 As RadioButton
    Friend WithEvents Panel47 As Panel
    Friend WithEvents rb992 As RadioButton
    Friend WithEvents rb991 As RadioButton
    Friend WithEvents Panel49 As Panel
    Friend WithEvents rb982 As RadioButton
    Friend WithEvents rb981 As RadioButton
    Friend WithEvents Panel50 As Panel
    Friend WithEvents rb972 As RadioButton
    Friend WithEvents rb971 As RadioButton
    Friend WithEvents Panel51 As Panel
    Friend WithEvents rb962 As RadioButton
    Friend WithEvents rb961 As RadioButton
    Friend WithEvents Panel52 As Panel
    Friend WithEvents rb952 As RadioButton
    Friend WithEvents rb951 As RadioButton
    Friend WithEvents Panel53 As Panel
    Friend WithEvents rb942 As RadioButton
    Friend WithEvents rb941 As RadioButton
    Friend WithEvents Panel54 As Panel
    Friend WithEvents rb932 As RadioButton
    Friend WithEvents rb931 As RadioButton
    Friend WithEvents Panel55 As Panel
    Friend WithEvents rb922 As RadioButton
    Friend WithEvents rb921 As RadioButton
    Friend WithEvents Panel56 As Panel
    Friend WithEvents rb912 As RadioButton
    Friend WithEvents rb911 As RadioButton
    Friend WithEvents Label127 As Label
    Friend WithEvents Label125 As Label
    Friend WithEvents Panel57 As Panel
    Friend WithEvents rbEpostNei As RadioButton
    Friend WithEvents rbEpostJa As RadioButton
    Friend WithEvents Panel58 As Panel
    Friend WithEvents rbSMSNei As RadioButton
    Friend WithEvents rbSMSJa As RadioButton
    Friend WithEvents Panel59 As Panel
    Friend WithEvents rb1102 As RadioButton
    Friend WithEvents rb3101 As RadioButton
    Friend WithEvents Panel60 As Panel
    Friend WithEvents rb392 As RadioButton
    Friend WithEvents rb391 As RadioButton
    Friend WithEvents btnInfo As Button
    Friend WithEvents lblDato As Label
    Friend WithEvents Label129 As Label
    Friend WithEvents Panel61 As Panel
    Friend WithEvents rb152 As RadioButton
    Friend WithEvents rb151 As RadioButton
    Friend WithEvents Label130 As Label
    Friend WithEvents Panel62 As Panel
    Friend WithEvents rb162 As RadioButton
    Friend WithEvents rb161 As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents chkSjekk As CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblFornavn As Label
    Friend WithEvents lblEtternavn As Label
    Friend WithEvents label4030 As Label
    Friend WithEvents lblPersonID As Label
End Class
